# سجل تغييرات الملفات للحزمة: `UPDATE_0006_DELTA`

| العملية (`Operation`) | مسار الملف (`Path`) | الحجم (`Bytes`) | نوع الملف (`Type`) | SHA-256 السابق | SHA-256 الجديد |
| :---: | :--- | :---: | :---: | :---: | :---: |
| `MODIFY` | `memory/FUNCTION_REGISTRY.md` | 96905 | Text | `0d721ca32fd4...` | `6cb089123c04...` |
| `MODIFY` | `memory/code_mirrors/tools__update_packages__applier.py.md` | 48994 | Text | `498b18ff64e0...` | `3057d325a87f...` |
| `MODIFY` | `memory/code_mirrors/tools__update_packages__cli.py.md` | 18695 | Text | `2eb5e72cc86b...` | `daa882967b08...` |
| `MODIFY` | `memory/code_mirrors/tools__update_packages__packager.py.md` | 35229 | Text | `5b764411571d...` | `c61fea19e7e1...` |
| `MODIFY` | `memory/code_mirrors/tools__update_packages__tests__test_update_system.py.md` | 134802 | Text | `23906d60ee3a...` | `816fd8735cf6...` |
| `MODIFY` | `memory/code_mirrors/tools__update_packages__verifier.py.md` | 25765 | Text | `43a3ec97797a...` | `7cc823de8d02...` |
| `MODIFY` | `memory/session/ACTIVE_SESSION_WAL.md` | 132530 | Text | `c71b2c4801e4...` | `3369fcd862d2...` |
| `MODIFY` | `memory/session/CURRENT_TASK_CHECKPOINT.md` | 29057 | Text | `163c65c77530...` | `d59a63469e94...` |
| `MODIFY` | `tools/memory_guard/brain_validation.json` | 1035 | Text | `c73cd1ac50b6...` | `1c7aa40d4ae8...` |
| `MODIFY` | `tools/tests/governance_test_report.json` | 3766 | Text | `1a6bfbb832be...` | `4e8bdf9d34fd...` |
| `MODIFY` | `tools/update_packages/applier.py` | 23177 | Text | `3dc92a42400c...` | `b3d398b920f4...` |
| `MODIFY` | `tools/update_packages/cli.py` | 13094 | Text | `e6a3960cb43d...` | `489c2da161bf...` |
| `MODIFY` | `tools/update_packages/packager.py` | 16145 | Text | `cd0624c99b51...` | `fe2487da5b8f...` |
| `MODIFY` | `tools/update_packages/tests/test_update_system.py` | 53632 | Text | `7c62e0f9dd31...` | `979c7b183724...` |
| `MODIFY` | `tools/update_packages/verifier.py` | 13391 | Text | `3604797b0612...` | `2b8ff0736007...` |
