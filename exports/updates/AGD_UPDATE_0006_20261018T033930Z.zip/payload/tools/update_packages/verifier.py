# START CHANGE TASK-UPDATE-SYS-CORRECTION-01 | 2026-10-18T02:00:00Z | EDITED | Author: orchestrator-planner
"""Verification and security auditing of update ZIP packages."""

from __future__ import annotations
from pathlib import Path, PurePosixPath
from typing import Any, Dict, List, Set, Tuple
from zipfile import ZipFile, BadZipFile
import json
import re

from .models import UpdateManifest
from .scanner import compute_bytes_sha256

WINDOWS_RESERVED_NAMES: Set[str] = {
    "CON", "PRN", "AUX", "NUL",
    "COM1", "COM2", "COM3", "COM4", "COM5", "COM6", "COM7", "COM8", "COM9",
    "LPT1", "LPT2", "LPT3", "LPT4", "LPT5", "LPT6", "LPT7", "LPT8", "LPT9"
}

ALLOWED_ROOT_FILES: Set[str] = {
    "UPDATE_MANIFEST.json",
    "UPDATE_README.md",
    "FILE_CHANGES.md",
    "VALIDATION_RESULTS.json",
    "EXCLUSIONS.json"
}


def is_safe_relative_path(path_str: str) -> Tuple[bool, str]:
    """Audit a path against directory traversal, absolute paths, drive letters, and invalid characters."""
    if not path_str or not isinstance(path_str, str):
        return False, "Path is empty or not a string"
    if "\x00" in path_str:
        return False, "Path contains null byte"

    norm = path_str.replace("\\", "/")
    if norm.startswith("/"):
        return False, "Leading root slash not allowed"
    if norm.startswith("//") or path_str.startswith("\\\\"):
        return False, "UNC path not allowed"
    if re.match(r"^[a-zA-Z]:", norm):
        return False, "Windows drive letter not allowed"
    if ":" in norm:
        return False, "Colon in path not allowed"

    parts = norm.split("/")
    if any(part == ".." for part in parts):
        return False, "Directory traversal '..' component not allowed"
    if any(part == "." for part in parts if len(parts) > 1):
        return False, "Dot '.' segment in multi-part path not allowed"
    if any(part == "" for part in parts):
        return False, "Empty path segment or trailing slash not allowed"

    for part in parts:
        stem = part.split(".")[0].upper()
        if stem in WINDOWS_RESERVED_NAMES:
            return False, f"Windows reserved device name: {stem}"

    try:
        pure = PurePosixPath(norm)
        if pure.is_absolute() or ".." in pure.parts:
            return False, "PurePosixPath normalization detected traversal or absolute path"
    except Exception as e:
        return False, f"Path normalization failed: {e}"

    return True, ""


# START CHANGE TASK-UPDATE-SYS-HARDENING-01 | 2026-10-18T03:30:00Z | EDITED | Author: orchestrator-planner
def is_safe_archive_path(path_str: str) -> bool:
    """Audit archive entry path against directory traversal vulnerabilities."""
    safe, _ = is_safe_relative_path(path_str)
    return safe


def audit_path_ancestry_safety(target_dir: Path, rel_path: str) -> Tuple[bool, str]:
    """
    Validates that rel_path resolves strictly within target_dir, and no component
    in its ancestry or the destination itself escapes target_dir via symlinks, junctions, or hardlinks.
    Rejects unsafe symlink destinations and symlink-based target replacements.
    """
    canonical_root = target_dir.resolve()
    safe, reason = is_safe_relative_path(rel_path)
    if not safe:
        return False, f"Relative path syntax violation: {reason}"

    # Walk each component from canonical root down to leaf
    parts = Path(rel_path).parts
    curr = canonical_root
    for part in parts:
        curr = curr / part
        # Check if curr is a symlink or junction
        if curr.is_symlink():
            try:
                resolved_link = curr.resolve()
                resolved_link.relative_to(canonical_root)
            except ValueError:
                return False, f"Symlink component '{part}' (at '{curr}') resolves outside repository root to '{resolved_link}'"
        elif curr.exists():
            try:
                resolved = curr.resolve()
                resolved.relative_to(canonical_root)
            except ValueError:
                return False, f"Component '{part}' (at '{curr}') resolves outside repository root to '{resolved}'"

    # Also resolve deepest existing ancestor for paths that don't exist yet
    target_file = target_dir / rel_path
    deepest = target_file
    non_existing: List[str] = []
    while not deepest.exists() and not deepest.is_symlink():
        if deepest == canonical_root or deepest.parent == deepest:
            break
        non_existing.append(deepest.name)
        deepest = deepest.parent

    try:
        resolved_deepest = deepest.resolve()
        resolved_deepest.relative_to(canonical_root)
    except ValueError:
        return False, f"Deepest existing parent component '{deepest}' resolves outside repository root to '{resolved_deepest}'"

    for part in reversed(non_existing):
        resolved_deepest = resolved_deepest / part

    try:
        resolved_deepest.relative_to(canonical_root)
    except ValueError:
        return False, f"Target path '{rel_path}' resolves outside repository root to '{resolved_deepest}'"

    return True, ""
# END CHANGE TASK-UPDATE-SYS-HARDENING-01 | 2026-10-18T03:30:00Z | EDITED


class PackageVerifier:
    """Verifies format, path safety, and byte-level hash integrity of update archives."""

    @staticmethod
    def verify_package(zip_path: Path) -> Dict[str, Any]:
        """Verify the integrity, safety, and content authenticity of an update ZIP."""
        zip_path = zip_path.resolve()
        if not zip_path.exists():
            return {
                "status": "INVALID",
                "errors": [f"Archive file not found: {zip_path}"],
                "manifest": None
            }

        errors: List[str] = []
        manifest: Any = None
        try:
            with ZipFile(zip_path, "r") as zf:
                names = zf.namelist()

                # 1. Audit archive entry name safety and boundary
                for name in names:
                    safe, reason = is_safe_relative_path(name)
                    if not safe:
                        errors.append(f"Unsafe archive entry path: {name} ({reason})")
                    elif name not in ALLOWED_ROOT_FILES and not name.startswith("payload/"):
                        errors.append(f"Unexpected archive entry outside root controls or payload/: {name}")

                if errors:
                    return {"status": "INVALID", "errors": errors, "manifest": None}

                # 2. Check manifest existence
                if "UPDATE_MANIFEST.json" not in names:
                    return {
                        "status": "INVALID",
                        "errors": ["Missing UPDATE_MANIFEST.json at root of archive"],
                        "manifest": None
                    }

                # 3. Read and parse manifest
                try:
                    manifest_bytes = zf.read("UPDATE_MANIFEST.json")
                    manifest_data = json.loads(manifest_bytes.decode("utf-8"))
                    manifest = UpdateManifest.from_dict(manifest_data)
                except Exception as e:
                    return {
                        "status": "INVALID",
                        "errors": [f"Malformed UPDATE_MANIFEST.json: {str(e)}"],
                        "manifest": None
                    }

                # START CHANGE TASK-UPDATE-SYS-HARDENING-01 | 2026-10-18T03:30:00Z | EDITED | Author: orchestrator-planner
                # Enforce complete mode integrity: COMPLETE packages must have zero exclusions
                if getattr(manifest, "package_mode", "").upper() == "COMPLETE" and manifest.exclusions_count > 0:
                    errors.append(
                        f"COMPLETE package declares {manifest.exclusions_count} exclusions; COMPLETE mode updates must have zero required content exclusions."
                    )
                # END CHANGE TASK-UPDATE-SYS-HARDENING-01 | 2026-10-18T03:30:00Z | EDITED

                # 4. Strictly audit manifest entry paths against traversal and collisions
                seen_target_paths: Set[str] = set()
                declared_payload_paths: Set[str] = set()
                sha_hex_pattern = re.compile(r"^[0-9a-f]{64}$")

                for entry in manifest.entries:
                    # Validate entry.path
                    safe, reason = is_safe_relative_path(entry.path)
                    if not safe:
                        errors.append(f"Unsafe target path in manifest entry: {entry.path} ({reason})")

                    if entry.path in seen_target_paths:
                        errors.append(f"Duplicate target path declared in manifest: {entry.path}")
                    seen_target_paths.add(entry.path)

                    # Validate payload_path if present
                    if entry.payload_path:
                        safe_pay, pay_reason = is_safe_relative_path(entry.payload_path)
                        if not safe_pay:
                            errors.append(f"Unsafe payload_path in manifest entry for {entry.path}: {entry.payload_path} ({pay_reason})")
                        elif not entry.payload_path.startswith("payload/"):
                            errors.append(f"Payload path does not start with payload/: {entry.payload_path}")
                        declared_payload_paths.add(entry.payload_path)

                    # Validate renamed_from if present
                    if entry.renamed_from:
                        safe_ren, ren_reason = is_safe_relative_path(entry.renamed_from)
                        if not safe_ren:
                            errors.append(f"Unsafe renamed_from path in manifest entry: {entry.renamed_from} ({ren_reason})")

                    # Validate hash formats
                    if entry.new_sha256 and not sha_hex_pattern.match(entry.new_sha256):
                        errors.append(f"Invalid new_sha256 format for {entry.path}: {entry.new_sha256}")
                    if entry.previous_sha256 and not sha_hex_pattern.match(entry.previous_sha256):
                        errors.append(f"Invalid previous_sha256 format for {entry.path}: {entry.previous_sha256}")

                    # Validate payload content and byte hash against manifest
                    if entry.payload_path:
                        if entry.payload_path not in names:
                            errors.append(f"Payload file missing in archive: {entry.payload_path}")
                            continue

                        payload_bytes = zf.read(entry.payload_path)
                        payload_sha = compute_bytes_sha256(payload_bytes)

                        if payload_sha != entry.new_sha256:
                            errors.append(
                                f"Corrupted payload for {entry.path}: expected {entry.new_sha256}, got {payload_sha}"
                            )
                        if len(payload_bytes) != entry.size_bytes:
                            errors.append(
                                f"Byte size mismatch for {entry.path}: expected {entry.size_bytes}, got {len(payload_bytes)}"
                            )

                # 5. Check for undeclared payload files in ZIP
                actual_payload_files = {name for name in names if name.startswith("payload/")}
                undeclared_payloads = actual_payload_files - declared_payload_paths
                if undeclared_payloads:
                    for up in sorted(undeclared_payloads):
                        errors.append(f"Undeclared payload file found in archive: {up}")

                # 6. Validate auxiliary EXCLUSIONS.json if present
                if "EXCLUSIONS.json" in names:
                    try:
                        excl_bytes = zf.read("EXCLUSIONS.json")
                        excl_list = json.loads(excl_bytes.decode("utf-8"))
                        if not isinstance(excl_list, list):
                            errors.append("EXCLUSIONS.json must be a JSON array")
                        else:
                            for ex in excl_list:
                                ex_path = ex.get("path", "")
                                safe_ex, ex_reason = is_safe_relative_path(ex_path)
                                if not safe_ex:
                                    errors.append(f"Unsafe path in EXCLUSIONS.json: {ex_path} ({ex_reason})")
                    except Exception as e:
                        errors.append(f"Malformed EXCLUSIONS.json: {e}")

        except BadZipFile:
            return {
                "status": "INVALID",
                "errors": [f"Corrupted or invalid ZIP file: {zip_path}"],
                "manifest": None
            }
        except Exception as e:
            return {
                "status": "INVALID",
                "errors": [f"Unexpected error inspecting archive: {str(e)}"],
                "manifest": None
            }

        if errors:
            return {"status": "INVALID", "errors": errors, "manifest": manifest.to_dict() if manifest else None}

        return {
            "status": "VALID",
            "errors": [],
            "manifest": manifest.to_dict(),
            "entries_count": len(manifest.entries),
            "payload_files_count": len([e for e in manifest.entries if e.payload_path]),
            "mode": manifest.package_mode
        }
# END CHANGE TASK-UPDATE-SYS-CORRECTION-01 | 2026-10-18T02:00:00Z | EDITED
