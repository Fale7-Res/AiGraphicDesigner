# سجل تغييرات الملفات للحزمة: `UPDATE_0008_DELTA`

| العملية (`Operation`) | مسار الملف (`Path`) | الحجم (`Bytes`) | نوع الملف (`Type`) | SHA-256 السابق | SHA-256 الجديد |
| :---: | :--- | :---: | :---: | :---: | :---: |
| `MODIFY` | `memory/DOCUMENT_PROVENANCE.json` | 80773 | Text | `df4e47e221ce...` | `11c2d4d72668...` |
| `MODIFY` | `memory/FUNCTION_REGISTRY.md` | 97893 | Text | `0d721ca32fd4...` | `374b035cf622...` |
| `MODIFY` | `memory/code_mirrors/tools__update_packages__applier.py.md` | 53262 | Text | `498b18ff64e0...` | `450667cffa5f...` |
| `MODIFY` | `memory/code_mirrors/tools__update_packages__cli.py.md` | 19288 | Text | `2eb5e72cc86b...` | `cb0ab4f89c0f...` |
| `MODIFY` | `memory/code_mirrors/tools__update_packages__packager.py.md` | 36367 | Text | `5b764411571d...` | `8656e01e4db7...` |
| `MODIFY` | `memory/code_mirrors/tools__update_packages__state_manager.py.md` | 24925 | Text | `72ca8b4bd0c1...` | `e38f76b07af6...` |
| `MODIFY` | `memory/code_mirrors/tools__update_packages__tests__test_update_system.py.md` | 152765 | Text | `23906d60ee3a...` | `3cfda9bf3d9c...` |
| `MODIFY` | `memory/code_mirrors/tools__update_packages__verifier.py.md` | 34477 | Text | `43a3ec97797a...` | `d72940717069...` |
| `MODIFY` | `memory/session/ACTIVE_SESSION_WAL.md` | 138270 | Text | `c71b2c4801e4...` | `60cce5bd3b80...` |
| `MODIFY` | `memory/session/CURRENT_TASK_CHECKPOINT.md` | 31609 | Text | `163c65c77530...` | `35320292bec5...` |
| `MODIFY` | `tools/memory_guard/brain_validation.json` | 1035 | Text | `c73cd1ac50b6...` | `7e31c6bd6513...` |
| `MODIFY` | `tools/project_catalog/validation.json` | 281 | Text | `63170c02ef17...` | `e2e4f5186cf5...` |
| `MODIFY` | `tools/tests/governance_test_report.json` | 3766 | Text | `1a6bfbb832be...` | `e7126a1a4ad1...` |
| `MODIFY` | `tools/update_packages/applier.py` | 25481 | Text | `3dc92a42400c...` | `436ffb046da9...` |
| `MODIFY` | `tools/update_packages/cli.py` | 13681 | Text | `e6a3960cb43d...` | `de3173e81323...` |
| `MODIFY` | `tools/update_packages/packager.py` | 16708 | Text | `cd0624c99b51...` | `d77273146773...` |
| `MODIFY` | `tools/update_packages/state_manager.py` | 8043 | Text | `bf4ec673998a...` | `6bd01c996a15...` |
| `MODIFY` | `tools/update_packages/tests/test_update_system.py` | 61780 | Text | `7c62e0f9dd31...` | `738ddbf991e3...` |
| `MODIFY` | `tools/update_packages/verifier.py` | 17971 | Text | `3604797b0612...` | `4c5694d3c7ce...` |
