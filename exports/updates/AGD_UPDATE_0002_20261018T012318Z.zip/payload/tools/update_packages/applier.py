# START CHANGE TASK-UPDATE-SYS-01 | 2026-10-18T01:15:00Z | CREATED | Author: orchestrator-planner
"""Transactional, safe application of update packages to a workspace."""

from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Optional
from zipfile import ZipFile
import shutil
import tempfile

from .models import FileOperation, UpdateManifest
from .scanner import WorkspaceScanner, calculate_stream_sha256
from .verifier import PackageVerifier


class PackageApplier:
    """Applies verified update packages safely and transactionally to a target workspace."""

    def __init__(self, target_dir: Path, enforce_base_match: bool = True):
        self.target_dir = target_dir.resolve()
        self.enforce_base_match = enforce_base_match

    def apply(self, zip_path: Path, dry_run: bool = False) -> Dict[str, Any]:
        """Apply an update ZIP package transactionally to the target directory."""
        # 1. Verify archive format and hashes
        verification = PackageVerifier.verify_package(zip_path)
        if verification["status"] != "VALID":
            return {
                "status": "FAILED",
                "stage": "VERIFICATION",
                "errors": verification["errors"]
            }

        manifest = UpdateManifest.from_dict(verification["manifest"])

        # 2. Check prerequisites against target workspace
        scanner = WorkspaceScanner(self.target_dir)
        current_target_files = scanner.scan()

        prereq_errors: List[str] = []
        for entry in manifest.entries:
            target_path = self.target_dir / entry.path
            current_rec = current_target_files.get(entry.path)

            if entry.operation in (FileOperation.MODIFY.value, FileOperation.DELETE.value):
                if not current_rec:
                    prereq_errors.append(f"Expected file to modify/delete not found in target: {entry.path}")
                elif self.enforce_base_match and entry.previous_sha256:
                    if current_rec.sha256 != entry.previous_sha256:
                        prereq_errors.append(
                            f"Base hash collision for {entry.path}: expected {entry.previous_sha256[:12]}..., found {current_rec.sha256[:12]}..."
                        )

            elif entry.operation == FileOperation.RENAME.value:
                old_rec = current_target_files.get(entry.renamed_from) if entry.renamed_from else None
                if not old_rec:
                    prereq_errors.append(f"Source file for rename not found: {entry.renamed_from}")
                elif self.enforce_base_match and entry.previous_sha256 and old_rec.sha256 != entry.previous_sha256:
                    prereq_errors.append(
                        f"Base hash collision for rename source {entry.renamed_from}: expected {entry.previous_sha256[:12]}..."
                    )

            elif entry.operation == FileOperation.ADD.value:
                if current_rec:
                    if self.enforce_base_match and current_rec.sha256 != entry.new_sha256:
                        prereq_errors.append(f"Cannot ADD file; path already exists with differing content: {entry.path}")

        if prereq_errors:
            return {
                "status": "FAILED",
                "stage": "PREREQUISITE_CHECK",
                "errors": prereq_errors
            }

        if dry_run:
            return {
                "status": "DRY_RUN_PASSED",
                "stage": "PREREQUISITE_CHECK",
                "update_id": manifest.update_id,
                "operations_count": len(manifest.entries),
                "target_dir": str(self.target_dir)
            }

        # 3. Stage payload extraction into temporary directory
        with tempfile.TemporaryDirectory(prefix="agd_stage_") as stage_dir_str:
            stage_dir = Path(stage_dir_str)
            try:
                with ZipFile(zip_path, "r") as zf:
                    for entry in manifest.entries:
                        if entry.payload_path:
                            dest = stage_dir / entry.path
                            dest.parent.mkdir(parents=True, exist_ok=True)
                            payload_bytes = zf.read(entry.payload_path)
                            dest.write_bytes(payload_bytes)
            except Exception as e:
                return {
                    "status": "FAILED",
                    "stage": "STAGING_EXTRACTION",
                    "errors": [f"Failed to extract payload to staging: {str(e)}"]
                }

            # 4. Transactionally apply modifications to target workspace
            applied_entries: List[str] = []
            try:
                for entry in manifest.entries:
                    target_file = self.target_dir / entry.path

                    if entry.operation in (FileOperation.ADD.value, FileOperation.MODIFY.value):
                        staged_file = stage_dir / entry.path
                        target_file.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(staged_file, target_file)
                        applied_entries.append(f"{entry.operation}: {entry.path}")

                    elif entry.operation == FileOperation.RENAME.value:
                        if entry.renamed_from:
                            old_file = self.target_dir / entry.renamed_from
                            if old_file.exists():
                                old_file.unlink()
                        staged_file = stage_dir / entry.path
                        target_file.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(staged_file, target_file)
                        applied_entries.append(f"RENAME: {entry.renamed_from} -> {entry.path}")

                    elif entry.operation == FileOperation.DELETE.value:
                        if target_file.exists():
                            target_file.unlink()
                            applied_entries.append(f"DELETE: {entry.path}")

            except Exception as e:
                return {
                    "status": "FAILED",
                    "stage": "APPLICATION_EXECUTION",
                    "errors": [f"Fatal error while applying files: {str(e)}"],
                    "applied_before_failure": applied_entries
                }

        return {
            "status": "APPLIED",
            "update_id": manifest.update_id,
            "mode": manifest.package_mode,
            "applied_count": len(applied_entries),
            "applied_entries": applied_entries,
            "target_dir": str(self.target_dir),
            "errors": []
        }
# END CHANGE TASK-UPDATE-SYS-01 | 2026-10-18T01:15:00Z | CREATED
