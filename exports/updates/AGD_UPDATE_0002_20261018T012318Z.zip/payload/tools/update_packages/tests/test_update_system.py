# START CHANGE TASK-UPDATE-SYS-01 | 2026-10-18T01:15:00Z | CREATED | Author: orchestrator-planner
"""Comprehensive test suite for the Incremental Update Packaging System.

Covers all 20 adversarial scenarios from B11 and the B12 end-to-end acceptance test.
All tests use disposable, isolated temporary directories.
"""

from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import json
import os
import shutil
import tempfile
import time
import unittest

from tools.update_packages.applier import PackageApplier
from tools.update_packages.differ import InventoryDiffer
from tools.update_packages.models import BaselineInventory, FileOperation, PackageMode, UpdateManifest
from tools.update_packages.packager import UpdatePackager
from tools.update_packages.scanner import WorkspaceScanner, compute_bytes_sha256, calculate_stream_sha256
from tools.update_packages.state_manager import UpdateStateManager
from tools.update_packages.verifier import PackageVerifier


class TestIncrementalUpdateSystem(unittest.TestCase):
    """Test suite covering B11 adversarial tests and B12 end-to-end acceptance."""

    def setUp(self):
        self.test_dir = tempfile.TemporaryDirectory(prefix="test_agd_update_")
        self.root = Path(self.test_dir.name).resolve()
        self.exports_dir = self.root / "exports" / "updates"
        self.exports_dir.mkdir(parents=True, exist_ok=True)

        # Populate a sample baseline repository
        (self.root / "src").mkdir(parents=True, exist_ok=True)
        (self.root / "docs").mkdir(parents=True, exist_ok=True)
        (self.root / "tests").mkdir(parents=True, exist_ok=True)
        (self.root / "assets").mkdir(parents=True, exist_ok=True)

        (self.root / "src" / "main.py").write_text("print('v1')\n", encoding="utf-8")
        (self.root / "docs" / "README.md").write_text("# Project v1\n", encoding="utf-8")
        (self.root / "assets" / "logo.png").write_bytes(b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR_v1")
        (self.root / "docs" / "to_delete.txt").write_text("Delete me\n", encoding="utf-8")
        (self.root / "docs" / "old_name.md").write_text("Rename me\n", encoding="utf-8")

        self.state_mgr = UpdateStateManager(self.root)
        self.base_inv = self.state_mgr.initialize_baseline("BASE_TEST_001")

    def tearDown(self):
        self.test_dir.cleanup()

    def test_01_modified_python_file(self):
        """Scenario 1: Modified Python file is detected and packaged."""
        (self.root / "src" / "main.py").write_text("print('v2 modified')\n", encoding="utf-8")
        scanner = WorkspaceScanner(self.root)
        curr = scanner.scan()
        entries, summary = InventoryDiffer.compute_diff(self.base_inv.files, curr)

        self.assertEqual(summary["modified"], 1)
        self.assertEqual(entries[0].path, "src/main.py")
        self.assertEqual(entries[0].operation, FileOperation.MODIFY.value)

    def test_02_added_markdown_file(self):
        """Scenario 2: Newly added Markdown document is detected."""
        (self.root / "docs" / "NEW_GUIDE.md").write_text("# New Guide\n", encoding="utf-8")
        scanner = WorkspaceScanner(self.root)
        curr = scanner.scan()
        entries, summary = InventoryDiffer.compute_diff(self.base_inv.files, curr)

        self.assertEqual(summary["added"], 1)
        added_entry = next(e for e in entries if e.path == "docs/NEW_GUIDE.md")
        self.assertEqual(added_entry.operation, FileOperation.ADD.value)

    def test_03_deleted_file(self):
        """Scenario 3: Deleted file is properly marked as DELETE without payload."""
        (self.root / "docs" / "to_delete.txt").unlink()
        scanner = WorkspaceScanner(self.root)
        curr = scanner.scan()
        entries, summary = InventoryDiffer.compute_diff(self.base_inv.files, curr)

        self.assertEqual(summary["deleted"], 1)
        del_entry = next(e for e in entries if e.path == "docs/to_delete.txt")
        self.assertEqual(del_entry.operation, FileOperation.DELETE.value)
        self.assertIsNone(del_entry.payload_path)

    def test_04_renamed_file(self):
        """Scenario 4: File rename is correctly identified via SHA-256 match."""
        # Rename old_name.md to new_name.md
        content = (self.root / "docs" / "old_name.md").read_bytes()
        (self.root / "docs" / "old_name.md").unlink()
        (self.root / "docs" / "new_name.md").write_bytes(content)

        scanner = WorkspaceScanner(self.root)
        curr = scanner.scan()
        entries, summary = InventoryDiffer.compute_diff(self.base_inv.files, curr)

        self.assertEqual(summary["renamed"], 1)
        rename_entry = next(e for e in entries if e.path == "docs/new_name.md")
        self.assertEqual(rename_entry.operation, FileOperation.RENAME.value)
        self.assertEqual(rename_entry.renamed_from, "docs/old_name.md")

    def test_05_modified_binary_file(self):
        """Scenario 5: Modified PNG binary is safely tracked and flagged as binary."""
        (self.root / "assets" / "logo.png").write_bytes(b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR_v2_updated_bytes")
        scanner = WorkspaceScanner(self.root)
        curr = scanner.scan()
        entries, summary = InventoryDiffer.compute_diff(self.base_inv.files, curr)

        self.assertEqual(summary["modified"], 1)
        bin_entry = next(e for e in entries if e.path == "assets/logo.png")
        self.assertTrue(bin_entry.is_binary)

    def test_06_arabic_unicode_filename(self):
        """Scenario 6: Arabic / Unicode filenames are preserved without encoding distortion."""
        arabic_name = "وثيقة_التصميم_العربي.md"
        (self.root / "docs" / arabic_name).write_text("# دليل التصميم باللغة العربية\n", encoding="utf-8")

        scanner = WorkspaceScanner(self.root)
        curr = scanner.scan()
        self.assertIn(f"docs/{arabic_name}", curr)

        target_inv = BaselineInventory(
            baseline_id="SNAP_ARABIC",
            repo_identity="Test",
            created_at_utc="2026-10-18T00:00:00Z",
            tool_version="1.0.0",
            files=curr
        )
        packager = UpdatePackager(self.root)
        res = packager.build_package(self.base_inv, target_inv, PackageMode.COMPLETE, "UPDATE_ARABIC", self.exports_dir)
        self.assertEqual(res["status"], "SUCCESS")

        verification = PackageVerifier.verify_package(Path(res["archive_path"]))
        self.assertEqual(verification["status"], "VALID")

    def test_07_content_changed_same_timestamp(self):
        """Scenario 7: Content changed with unchanged timestamp is still detected via SHA-256."""
        target_file = self.root / "src" / "main.py"
        old_stat = target_file.stat()
        target_file.write_text("print('timestamp unchanged but content changed')\n", encoding="utf-8")
        # Restore old mtime
        os.utime(target_file, (old_stat.st_atime, old_stat.st_mtime))

        scanner = WorkspaceScanner(self.root)
        curr = scanner.scan()
        entries, summary = InventoryDiffer.compute_diff(self.base_inv.files, curr)
        self.assertEqual(summary["modified"], 1)

    def test_08_untracked_new_file(self):
        """Scenario 8: Untracked new files in valid project directories are captured."""
        (self.root / "src" / "helper.py").write_text("def helper(): pass\n", encoding="utf-8")
        scanner = WorkspaceScanner(self.root)
        curr = scanner.scan()
        self.assertIn("src/helper.py", curr)

    def test_09_no_recursive_zip_inclusion(self):
        """Scenario 9: Previously exported ZIPs are strictly excluded and never packaged recursively."""
        dummy_zip = self.exports_dir / "AGD_UPDATE_0001_OLD.zip"
        dummy_zip.write_bytes(b"PK\x05\x06" + b"\x00" * 18)  # Empty ZIP bytes

        scanner = WorkspaceScanner(self.root)
        curr = scanner.scan()
        # Verify no .zip or exports/updates files appear in scanned inventory
        for p in curr:
            self.assertFalse(p.endswith(".zip"))
            self.assertFalse(p.startswith("exports/updates/"))

    def test_10_two_updates_before_acknowledgment(self):
        """Scenario 10: Two sequential exports preserve sequence and cumulative base."""
        # Export 1
        (self.root / "docs" / "file1.md").write_text("File 1\n", encoding="utf-8")
        scanner = WorkspaceScanner(self.root)
        target1 = BaselineInventory("SNAP_1", "Test", "2026-10-18T00:00:00Z", "1.0", files=scanner.scan())
        packager = UpdatePackager(self.root)
        res1 = packager.build_package(self.base_inv, target1, PackageMode.COMPLETE, "UPDATE_0001", self.exports_dir, sequence_num=1)
        self.state_mgr.record_export(res1)

        # Export 2 (cumulative against original unacknowledged baseline)
        (self.root / "docs" / "file2.md").write_text("File 2\n", encoding="utf-8")
        target2 = BaselineInventory("SNAP_2", "Test", "2026-10-18T00:00:00Z", "1.0", files=scanner.scan())
        res2 = packager.build_package(self.base_inv, target2, PackageMode.COMPLETE, "UPDATE_0002", self.exports_dir, sequence_num=2)
        self.state_mgr.record_export(res2)

        self.assertEqual(res2["summary"]["added"], 2)  # Contains both file1 and file2 cumulatively

    def test_11_apply_to_wrong_baseline_rejected(self):
        """Scenario 11: Applying update to an incompatible workspace baseline is rejected."""
        # Make a package modifying src/main.py
        (self.root / "src" / "main.py").write_text("v2\n", encoding="utf-8")
        scanner = WorkspaceScanner(self.root)
        target = BaselineInventory("SNAP_V2", "Test", "2026-10-18T00:00:00Z", "1.0", files=scanner.scan())
        packager = UpdatePackager(self.root)
        res = packager.build_package(self.base_inv, target, PackageMode.COMPLETE, "UPDATE_V2", self.exports_dir)

        # Create a foreign target directory with incompatible src/main.py
        with tempfile.TemporaryDirectory() as foreign_dir:
            f_root = Path(foreign_dir)
            (f_root / "src").mkdir(parents=True, exist_ok=True)
            (f_root / "src" / "main.py").write_text("foreign corrupted content\n", encoding="utf-8")

            applier = PackageApplier(f_root, enforce_base_match=True)
            apply_res = applier.apply(Path(res["archive_path"]))
            self.assertEqual(apply_res["status"], "FAILED")
            self.assertEqual(apply_res["stage"], "PREREQUISITE_CHECK")

    def test_12_tampered_payload_rejected(self):
        """Scenario 12: Archive with tampered payload bytes fails verification."""
        (self.root / "src" / "main.py").write_text("v2\n", encoding="utf-8")
        scanner = WorkspaceScanner(self.root)
        target = BaselineInventory("SNAP_V2", "Test", "2026-10-18T00:00:00Z", "1.0", files=scanner.scan())
        packager = UpdatePackager(self.root)
        res = packager.build_package(self.base_inv, target, PackageMode.COMPLETE, "UPDATE_V2", self.exports_dir)
        zip_path = Path(res["archive_path"])

        # Tamper with the ZIP by overwriting payload/src/main.py with different bytes
        tampered_zip_path = zip_path.with_name("tampered.zip")
        with ZipFile(zip_path, "r") as zf_in, ZipFile(tampered_zip_path, "w") as zf_out:
            for item in zf_in.infolist():
                if item.filename == "payload/src/main.py":
                    zf_out.writestr(item, b"malicious tampered content\n")
                else:
                    zf_out.writestr(item, zf_in.read(item.filename))

        verification = PackageVerifier.verify_package(tampered_zip_path)
        self.assertEqual(verification["status"], "INVALID")
        self.assertTrue(any("Corrupted payload" in e for e in verification["errors"]))

    def test_13_path_traversal_attack_rejected(self):
        """Scenario 13: Archive with directory traversal attacks (../) is rejected."""
        malicious_zip = self.exports_dir / "evil.zip"
        with ZipFile(malicious_zip, "w") as zf:
            zf.writestr("UPDATE_MANIFEST.json", "{}")
            zf.writestr("payload/../../escaped.txt", b"evil data")

        verification = PackageVerifier.verify_package(malicious_zip)
        self.assertEqual(verification["status"], "INVALID")
        self.assertTrue(any("traversal" in e for e in verification["errors"]))

    def test_14_failure_interrupted_export_leaves_clean_state(self):
        """Scenario 14: An interrupted export cleans up temporary files without corrupting output."""
        packager = UpdatePackager(self.root)
        scanner_file = WorkspaceScanner(self.root).scan()["src/main.py"]
        corrupted_inv = BaselineInventory(
            baseline_id="SNAP_GHOST",
            repo_identity="Test",
            created_at_utc="2026-10-18T00:00:00Z",
            tool_version="1.0",
            files={
                "ghost.txt": scanner_file
            }
        )
        corrupted_inv.files["ghost.txt"].path = "non_existent_ghost.txt"

        with self.assertRaises(FileNotFoundError):
            packager.build_package(self.base_inv, corrupted_inv, PackageMode.COMPLETE, "UPDATE_GHOST", self.exports_dir)

        # Verify no half-baked temporary files remain in exports_dir
        tmp_files = list(self.exports_dir.glob("*.tmp"))
        self.assertEqual(len(tmp_files), 0)

    def test_15_failure_interrupted_apply_leaves_clean_target(self):
        """Scenario 15: Interrupted apply does not corrupt target workspace."""
        (self.root / "src" / "main.py").write_text("v2\n", encoding="utf-8")
        scanner = WorkspaceScanner(self.root)
        target = BaselineInventory("SNAP_V2", "Test", "2026-10-18T00:00:00Z", "1.0", files=scanner.scan())
        packager = UpdatePackager(self.root)
        res = packager.build_package(self.base_inv, target, PackageMode.COMPLETE, "UPDATE_V2", self.exports_dir)
        zip_path = Path(res["archive_path"])

        # Tamper manifest to reference missing payload to force failure during staging
        tampered_zip = self.exports_dir / "broken_manifest.zip"
        with ZipFile(zip_path, "r") as zf_in, ZipFile(tampered_zip, "w") as zf_out:
            manifest = json.loads(zf_in.read("UPDATE_MANIFEST.json").decode("utf-8"))
            manifest["entries"][0]["payload_path"] = "payload/missing_ghost.py"
            zf_out.writestr("UPDATE_MANIFEST.json", json.dumps(manifest).encode("utf-8"))
            for item in zf_in.infolist():
                if item.filename != "UPDATE_MANIFEST.json":
                    zf_out.writestr(item, zf_in.read(item.filename))

        with tempfile.TemporaryDirectory() as target_dir:
            t_root = Path(target_dir)
            (t_root / "src").mkdir(parents=True, exist_ok=True)
            (t_root / "src" / "main.py").write_text("original", encoding="utf-8")

            applier = PackageApplier(t_root, enforce_base_match=False)
            apply_res = applier.apply(tampered_zip)
            self.assertEqual(apply_res["status"], "FAILED")
            # Ensure target file was NOT modified
            self.assertEqual((t_root / "src" / "main.py").read_text(encoding="utf-8"), "original")

    def test_16_missing_binary_detected(self):
        """Scenario 16: Missing binary asset referenced in manifest is caught."""
        (self.root / "assets" / "new_img.png").write_bytes(b"\x89PNG_new")
        scanner = WorkspaceScanner(self.root)
        curr = scanner.scan()
        (self.root / "assets" / "new_img.png").unlink()  # Delete before packager reads it

        target = BaselineInventory("SNAP_IMG", "Test", "2026-10-18T00:00:00Z", "1.0", files=curr)
        packager = UpdatePackager(self.root)
        with self.assertRaises(FileNotFoundError):
            packager.build_package(self.base_inv, target, PackageMode.COMPLETE, "UPDATE_IMG", self.exports_dir)

    def test_17_secret_bearing_files_excluded(self):
        """Scenario 17: .env, API keys, and private keys are screened out."""
        (self.root / ".env").write_text("SECRET_API_KEY=supersecret123\n", encoding="utf-8")
        (self.root / ".env.production").write_text("SECRET_TOKEN=xyz\n", encoding="utf-8")
        (self.root / "id_rsa").write_text("-----BEGIN RSA PRIVATE KEY-----\n", encoding="utf-8")

        scanner = WorkspaceScanner(self.root)
        curr = scanner.scan()
        self.assertNotIn(".env", curr)
        self.assertNotIn(".env.production", curr)
        self.assertNotIn("id_rsa", curr)

    def test_18_clean_checkout_portability(self):
        """Scenario 18: Generated update archive is a self-contained portable ZIP."""
        (self.root / "docs" / "PORTABLE.md").write_text("Portable\n", encoding="utf-8")
        scanner = WorkspaceScanner(self.root)
        target = BaselineInventory("SNAP_PORT", "Test", "2026-10-18T00:00:00Z", "1.0", files=scanner.scan())
        packager = UpdatePackager(self.root)
        res = packager.build_package(self.base_inv, target, PackageMode.REVIEW, "UPDATE_PORT", self.exports_dir)

        # Test extracting with pure python standard library without any local path references
        with tempfile.TemporaryDirectory() as extract_dir:
            shutil.unpack_archive(res["archive_path"], extract_dir)
            self.assertTrue((Path(extract_dir) / "UPDATE_MANIFEST.json").exists())
            self.assertTrue((Path(extract_dir) / "UPDATE_README.md").exists())
            self.assertTrue((Path(extract_dir) / "payload" / "docs" / "PORTABLE.md").exists())

    def test_19_windows_path_normalization(self):
        """Scenario 19: Windows backslashes are normalized to canonical POSIX forward slashes."""
        scanner = WorkspaceScanner(self.root)
        curr = scanner.scan()
        for p in curr:
            self.assertNotIn("\\", p)
            self.assertFalse(p.startswith("/"))

    def test_20_and_b12_end_to_end_acceptance(self):
        """B12 Acceptance Test: Full round-trip delta reconstruction and verification."""
        # 1. Create untouched clone of original baseline
        with tempfile.TemporaryDirectory(prefix="clone_base_") as clone_dir_str:
            clone_root = Path(clone_dir_str).resolve()
            # Copy all files from self.root to clone_root (excluding exports)
            for p, rec in self.base_inv.files.items():
                src_f = self.root / p
                dst_f = clone_root / p
                dst_f.parent.mkdir(parents=True, exist_ok=True)
                shutil.copy2(src_f, dst_f)

            # 2. Perform a realistic multi-operation change in self.root:
            # - Source edit
            (self.root / "src" / "main.py").write_text("print('version 2.0 release')\n", encoding="utf-8")
            # - Documentation edit
            (self.root / "docs" / "README.md").write_text("# Project v2.0\nUpdated docs.\n", encoding="utf-8")
            # - New file addition
            (self.root / "docs" / "NEW_FEATURE.md").write_text("# Brand New Feature\n", encoding="utf-8")
            # - Binary modification
            (self.root / "assets" / "logo.png").write_bytes(b"\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR_v2_new_logo_bytes")
            # - File deletion
            (self.root / "docs" / "to_delete.txt").unlink()
            # - File rename
            rename_content = (self.root / "docs" / "old_name.md").read_bytes()
            (self.root / "docs" / "old_name.md").unlink()
            (self.root / "docs" / "renamed_doc.md").write_bytes(rename_content)

            # 3. Scan target state
            scanner = WorkspaceScanner(self.root)
            target_files = scanner.scan()
            target_inv = BaselineInventory(
                baseline_id="SNAP_TARGET_RELEASE",
                repo_identity="Test Acceptance",
                created_at_utc="2026-10-18T00:00:00Z",
                tool_version="1.0.0",
                files=target_files
            )

            # 4. Export COMPLETE update package
            packager = UpdatePackager(self.root)
            pkg_res = packager.build_package(
                base_inventory=self.base_inv,
                target_inventory=target_inv,
                mode=PackageMode.COMPLETE,
                update_id="UPDATE_ACCEPTANCE_001",
                output_dir=self.exports_dir,
                sequence_num=100
            )
            self.assertEqual(pkg_res["status"], "SUCCESS")
            zip_file = Path(pkg_res["archive_path"])

            # 5. Apply update package onto the untouched clone of original baseline
            applier = PackageApplier(clone_root, enforce_base_match=True)
            apply_res = applier.apply(zip_file)
            self.assertEqual(apply_res["status"], "APPLIED")

            # 6. Verify resulting project state against target inventory 100% byte-for-byte!
            reconstructed_scanner = WorkspaceScanner(clone_root)
            reconstructed_files = reconstructed_scanner.scan()

            self.assertEqual(set(reconstructed_files.keys()), set(target_files.keys()))
            for p, target_rec in target_files.items():
                self.assertEqual(
                    reconstructed_files[p].sha256,
                    target_rec.sha256,
                    f"SHA-256 mismatch for reconstructed file: {p}"
                )

            # 7. Test that the update is rejected against wrong baseline
            with tempfile.TemporaryDirectory() as wrong_dir:
                wrong_root = Path(wrong_dir)
                (wrong_root / "src").mkdir(parents=True, exist_ok=True)
                (wrong_root / "src" / "main.py").write_text("random mismatched content", encoding="utf-8")
                wrong_applier = PackageApplier(wrong_root, enforce_base_match=True)
                self.assertEqual(wrong_applier.apply(zip_file)["status"], "FAILED")

            # 8. Test REVIEW mode package disclosure
            review_res = packager.build_package(
                base_inventory=self.base_inv,
                target_inventory=target_inv,
                mode=PackageMode.REVIEW,
                update_id="UPDATE_REVIEW_001",
                output_dir=self.exports_dir,
                sequence_num=101
            )
            self.assertEqual(review_res["mode"], "REVIEW")
            self.assertEqual(review_res["status"], "SUCCESS")


if __name__ == "__main__":
    unittest.main()
# END CHANGE TASK-UPDATE-SYS-01 | 2026-10-18T01:15:00Z | CREATED
