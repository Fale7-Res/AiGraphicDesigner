# START CHANGE TASK-UPDATE-SYS-01 | 2026-10-18T01:15:00Z | CREATED | Author: orchestrator-planner
"""Verification and security auditing of update ZIP packages."""

from __future__ import annotations
from pathlib import Path
from typing import Any, Dict, List, Tuple
from zipfile import ZipFile, BadZipFile
import json
import re

from .models import UpdateManifest
from .scanner import compute_bytes_sha256

UNSAFE_PATH_PATTERNS = [
    re.compile(r"^\.\.(/|\\|$)"),
    re.compile(r"(/|\\)\.\.(/|\\|$)"),
    re.compile(r"^[a-zA-Z]:"),  # Windows drive letter
    re.compile(r"^(/|\\)"),     # Root leading slash
]


def is_safe_archive_path(path_str: str) -> bool:
    """Audit archive path against directory traversal and absolute path vulnerabilities."""
    if "\x00" in path_str:
        return False
    norm = path_str.replace("\\", "/")
    for pat in UNSAFE_PATH_PATTERNS:
        if pat.search(norm):
            return False
    parts = norm.split("/")
    if ".." in parts:
        return False
    return True


class PackageVerifier:
    """Verifies format, path safety, and byte-level hash integrity of update archives."""

    @staticmethod
    def verify_package(zip_path: Path) -> Dict[str, Any]:
        """Verify the integrity, safety, and content authenticity of an update ZIP."""
        zip_path = zip_path.resolve()
        if not zip_path.exists():
            return {
                "status": "INVALID",
                "errors": [f"Archive file not found: {zip_path}"],
                "manifest": None
            }

        errors: List[str] = []
        try:
            with ZipFile(zip_path, "r") as zf:
                names = zf.namelist()

                # 1. Audit path traversal safety
                for name in names:
                    if not is_safe_archive_path(name):
                        errors.append(f"Unsafe path traversal detected in archive entry: {name}")

                if errors:
                    return {"status": "INVALID", "errors": errors, "manifest": None}

                # 2. Check manifest existence
                if "UPDATE_MANIFEST.json" not in names:
                    return {
                        "status": "INVALID",
                        "errors": ["Missing UPDATE_MANIFEST.json at root of archive"],
                        "manifest": None
                    }

                # 3. Read and parse manifest
                try:
                    manifest_bytes = zf.read("UPDATE_MANIFEST.json")
                    manifest_data = json.loads(manifest_bytes.decode("utf-8"))
                    manifest = UpdateManifest.from_dict(manifest_data)
                except Exception as e:
                    return {
                        "status": "INVALID",
                        "errors": [f"Malformed UPDATE_MANIFEST.json: {str(e)}"],
                        "manifest": None
                    }

                # 4. Verify each payload file's byte hash against manifest
                for entry in manifest.entries:
                    if not entry.payload_path:
                        continue
                    if entry.payload_path not in names:
                        errors.append(f"Payload file missing in archive: {entry.payload_path}")
                        continue

                    payload_bytes = zf.read(entry.payload_path)
                    payload_sha = compute_bytes_sha256(payload_bytes)

                    if payload_sha != entry.new_sha256:
                        errors.append(
                            f"Corrupted payload for {entry.path}: expected {entry.new_sha256}, got {payload_sha}"
                        )
                    if len(payload_bytes) != entry.size_bytes:
                        errors.append(
                            f"Byte size mismatch for {entry.path}: expected {entry.size_bytes}, got {len(payload_bytes)}"
                        )

        except BadZipFile:
            return {
                "status": "INVALID",
                "errors": [f"Corrupted or invalid ZIP file: {zip_path}"],
                "manifest": None
            }
        except Exception as e:
            return {
                "status": "INVALID",
                "errors": [f"Unexpected error inspecting archive: {str(e)}"],
                "manifest": None
            }

        if errors:
            return {"status": "INVALID", "errors": errors, "manifest": manifest.to_dict()}

        return {
            "status": "VALID",
            "errors": [],
            "manifest": manifest.to_dict(),
            "entries_count": len(manifest.entries),
            "payload_files_count": len([e for e in manifest.entries if e.payload_path]),
            "mode": manifest.package_mode
        }
# END CHANGE TASK-UPDATE-SYS-01 | 2026-10-18T01:15:00Z | CREATED
