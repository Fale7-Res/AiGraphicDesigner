# START CHANGE TASK-UPDATE-SYS-01 | 2026-10-18T01:15:00Z | CREATED | Author: orchestrator-planner
"""Workspace scanning, hashing, binary detection, and secret screening."""

from __future__ import annotations
from datetime import datetime, timezone
from pathlib import Path
from typing import Dict, List, Optional, Set, Tuple
import hashlib
import re

from .models import FileRecord

DEFAULT_EXCLUDED_DIR_NAMES: Set[str] = {
    ".git",
    "__pycache__",
    ".pytest_cache",
    "node_modules",
    "venv",
    ".venv",
    "env",
    ".env",
    "dist",
    "build",
    ".idea",
    ".vscode",
    ".system_generated"
}

DEFAULT_EXCLUDED_FILE_PATTERNS: List[re.Pattern] = [
    re.compile(r"^\.env(\..+)?$", re.IGNORECASE),
    re.compile(r".*\.pem$", re.IGNORECASE),
    re.compile(r".*\.key$", re.IGNORECASE),
    re.compile(r"^id_rsa(\..+)?$", re.IGNORECASE),
    re.compile(r"^id_ed25519(\..+)?$", re.IGNORECASE),
    re.compile(r".*\.tmp$", re.IGNORECASE),
    re.compile(r".*~$"),
    re.compile(r"^\.#.*$"),
    re.compile(r"^\.DS_Store$"),
    re.compile(r"^Thumbs\.db$", re.IGNORECASE),
    re.compile(r".*\.zip$", re.IGNORECASE),  # Prevent packaging any ZIPs inside update packages
    re.compile(r".*\.pyc$", re.IGNORECASE),
]

BINARY_EXTENSIONS: Set[str] = {
    ".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp", ".ico",
    ".pdf", ".zip", ".tar", ".gz", ".bz2", ".7z",
    ".woff", ".woff2", ".ttf", ".otf", ".eot",
    ".exe", ".dll", ".so", ".dylib", ".bin", ".pyc"
}


def calculate_stream_sha256(file_path: Path) -> str:
    """Compute the SHA-256 hexadecimal digest of a file safely in 64 KiB chunks."""
    h = hashlib.sha256()
    with file_path.open("rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()


def compute_bytes_sha256(data: bytes) -> str:
    """Compute SHA-256 digest of raw byte content."""
    return hashlib.sha256(data).hexdigest()


def is_binary_file(file_path: Path) -> bool:
    """Check if file is binary by extension or null-byte heuristic in the first 8 KiB."""
    if file_path.suffix.lower() in BINARY_EXTENSIONS:
        return True
    try:
        with file_path.open("rb") as f:
            chunk = f.read(8192)
            if b"\x00" in chunk:
                return True
    except (OSError, PermissionError):
        return False
    return False


def is_secret_file(file_path: Path) -> bool:
    """Determine if a file name or path suggests it contains credentials/secrets."""
    name = file_path.name
    for pattern in DEFAULT_EXCLUDED_FILE_PATTERNS[:5]:
        if pattern.match(name):
            return True
    return False


class WorkspaceScanner:
    """Scans repository files and constructs deterministic inventory maps."""

    def __init__(
        self,
        root_dir: Path,
        excluded_dirs: Optional[Set[str]] = None,
        custom_excluded_subpaths: Optional[Set[str]] = None
    ):
        self.root_dir = root_dir.resolve()
        self.excluded_dirs = set(DEFAULT_EXCLUDED_DIR_NAMES)
        if excluded_dirs:
            self.excluded_dirs.update(excluded_dirs)
        self.custom_excluded_subpaths = custom_excluded_subpaths or set()

    def should_exclude_path(self, path: Path) -> Tuple[bool, str]:
        """Check if a path should be excluded, returning (is_excluded, reason)."""
        try:
            rel = path.relative_to(self.root_dir)
        except ValueError:
            return True, "Path outside workspace root"

        rel_parts = rel.parts
        # Check parent directories
        for part in rel_parts[:-1]:
            if part in self.excluded_dirs:
                return True, f"Excluded directory: {part}"

        # Check export and output directories to prevent recursion
        posix_rel = rel.as_posix()
        if posix_rel.startswith("exports/updates/") or posix_rel == "exports/updates":
            return True, "Update package output directory"
        if posix_rel.startswith("updates/packages/") or posix_rel.startswith("updates/baselines/"):
            return True, "Legacy update directory"
        if posix_rel.startswith("tools/update_packages/registry/") or posix_rel == "tools/update_packages/registry":
            return True, "Update tool internal state registry"

        for subpath in self.custom_excluded_subpaths:
            if posix_rel.startswith(subpath):
                return True, f"Custom excluded subpath: {subpath}"

        if path.is_file():
            name = path.name
            if is_secret_file(path):
                return True, f"Secret screening exclusion: {name}"
            for pat in DEFAULT_EXCLUDED_FILE_PATTERNS:
                if pat.match(name):
                    return True, f"Excluded file pattern: {pat.pattern}"

        return False, ""

    def scan(self) -> Dict[str, FileRecord]:
        """Scan workspace and return a dictionary of normalized_posix_path -> FileRecord."""
        records: Dict[str, FileRecord] = {}
        if not self.root_dir.exists():
            return records

        for p in sorted(self.root_dir.rglob("*")):
            if not p.is_file():
                continue
            is_excluded, _ = self.should_exclude_path(p)
            if is_excluded:
                continue

            rel_posix = p.relative_to(self.root_dir).as_posix()
            try:
                stat = p.stat()
                mtime_utc = datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat()
                records[rel_posix] = FileRecord(
                    path=rel_posix,
                    sha256=calculate_stream_sha256(p),
                    size_bytes=stat.st_size,
                    is_binary=is_binary_file(p),
                    last_modified_utc=mtime_utc
                )
            except (OSError, PermissionError):
                continue

        return records
# END CHANGE TASK-UPDATE-SYS-01 | 2026-10-18T01:15:00Z | CREATED
