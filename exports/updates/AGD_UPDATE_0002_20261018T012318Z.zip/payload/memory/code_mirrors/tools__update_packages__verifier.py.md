# مرآة الكود التفصيلية: `tools/update_packages/verifier.py`

> **تنبيه مرجعية الكود (`AUTO-GENERATED MIRROR — DO NOT HAND-EDIT CODE SNIPPETS`):**
> الملف البرمجي الأصلي `tools/update_packages/verifier.py` هو **المرجع التنفيذي الوحيد (`Sole Implementation Authority`)**. تم توليد هذه المرآة آلياً عبر `tools/memory_guard/sync_code_mirrors.py`؛ أي تعديل في الكود الأصلي يستلزم إعادة تشغيل أداة المزامنة فوراً لمنع تحول المرآة إلى نسخة قديمة (`Stale Copy`).

## 1. بطاقة تعريف الملف (`File Overview`)
- **المسار الفعلي (`Source File`):** `tools/update_packages/verifier.py`
- **الدور المعماري (`Architectural Role`):** First-Party Source Module
- **إجمالي عدد الأسطر (`Total Lines`):** `127` (`Lines 1–127`)
- **بصمة الملف (`SHA-256`):** `fd692d9aa64e49db32bcb984cf53b583d7d1619010ce0c4a8ed0ed2ec2790f48`
- **الوصف التفصيلي:** ملف برمجي ضمن معمارية AI Graphic Designer.

## 2. خريطة العلاقات وتدفق البيانات (`File Relationships — بياخد منين وبيرمي فين`)

| الاتجاه (`Direction`) | الملف أو المكوّن المرتبط (`Related Target / Source`) | البيانات أو الاستدعاء (`Payload / Call`) | تأثير التعديل (`Change Impact`) |
| :--- | :--- | :--- | :--- |
| **مستقل (`Standalone`)** | `None` | لا توجد ارتباطات خارجية مباشرة حالياً | مراجعة هذا الملف فقط عند التعديل. |

## 3. فهرس الدوال والكلاسات والرموز الداخلية (`Symbols, Methods & Nested Functions Table`)

| الاسم (`Symbol Name`) | النوع (`Kind`) | نطاق الأسطر (`Exact Lines`) | التوقيع (`Signature`) | الوظيفة التفصيلية (`Purpose`) |
| :--- | :--- | :--- | :--- | :--- |
| `is_safe_archive_path` | `function` | `Lines 22–33` | `def is_safe_archive_path(path_str: str) -> bool:` | Audit archive path against directory traversal and absolute path vulnerabilities. |
| `PackageVerifier` | `class` | `Lines 36–126` | `class PackageVerifier:` | Verifies format, path safety, and byte-level hash integrity of update archives. |
| `PackageVerifier.verify_package` | `method` | `Lines 40–126` | `def verify_package(zip_path: Path) -> Dict[str, Any]:` | Verify the integrity, safety, and content authenticity of an update ZIP. |

## 4. التوثيق بالسطر والمقتطفات الفعلية للكود (`Exact Line Numbers & Verbatim Code Snippets`)

### `is_safe_archive_path` — `Lines 22–33`
- **النوع:** `function`
- **نطاق الأسطر الدقيق:** من السطر `22` إلى السطر `33` (`Lines 22–33`)
- **الوظيفة:** Audit archive path against directory traversal and absolute path vulnerabilities.
- **الكود الفعلي (`Lines 22–33`):**
```python
def is_safe_archive_path(path_str: str) -> bool:
    """Audit archive path against directory traversal and absolute path vulnerabilities."""
    if "\x00" in path_str:
        return False
    norm = path_str.replace("\\", "/")
    for pat in UNSAFE_PATH_PATTERNS:
        if pat.search(norm):
            return False
    parts = norm.split("/")
    if ".." in parts:
        return False
    return True
```

### `PackageVerifier` — `Lines 36–126`
- **النوع:** `class`
- **نطاق الأسطر الدقيق:** من السطر `36` إلى السطر `126` (`Lines 36–126`)
- **الوظيفة:** Verifies format, path safety, and byte-level hash integrity of update archives.
- **الكود الفعلي (`Lines 36–126`):**
```python
class PackageVerifier:
    """Verifies format, path safety, and byte-level hash integrity of update archives."""

    @staticmethod
    def verify_package(zip_path: Path) -> Dict[str, Any]:
        """Verify the integrity, safety, and content authenticity of an update ZIP."""
        zip_path = zip_path.resolve()
        if not zip_path.exists():
            return {
                "status": "INVALID",
                "errors": [f"Archive file not found: {zip_path}"],
                "manifest": None
            }

        errors: List[str] = []
        try:
            with ZipFile(zip_path, "r") as zf:
                names = zf.namelist()

                # 1. Audit path traversal safety
                for name in names:
                    if not is_safe_archive_path(name):
                        errors.append(f"Unsafe path traversal detected in archive entry: {name}")

                if errors:
                    return {"status": "INVALID", "errors": errors, "manifest": None}

                # 2. Check manifest existence
                if "UPDATE_MANIFEST.json" not in names:
                    return {
                        "status": "INVALID",
                        "errors": ["Missing UPDATE_MANIFEST.json at root of archive"],
                        "manifest": None
                    }

                # 3. Read and parse manifest
                try:
                    manifest_bytes = zf.read("UPDATE_MANIFEST.json")
                    manifest_data = json.loads(manifest_bytes.decode("utf-8"))
                    manifest = UpdateManifest.from_dict(manifest_data)
                except Exception as e:
                    return {
                        "status": "INVALID",
                        "errors": [f"Malformed UPDATE_MANIFEST.json: {str(e)}"],
                        "manifest": None
                    }

                # 4. Verify each payload file's byte hash against manifest
                for entry in manifest.entries:
                    if not entry.payload_path:
                        continue
                    if entry.payload_path not in names:
                        errors.append(f"Payload file missing in archive: {entry.payload_path}")
                        continue

                    payload_bytes = zf.read(entry.payload_path)
                    payload_sha = compute_bytes_sha256(payload_bytes)

                    if payload_sha != entry.new_sha256:
                        errors.append(
                            f"Corrupted payload for {entry.path}: expected {entry.new_sha256}, got {payload_sha}"
                        )
                    if len(payload_bytes) != entry.size_bytes:
                        errors.append(
                            f"Byte size mismatch for {entry.path}: expected {entry.size_bytes}, got {len(payload_bytes)}"
                        )

        except BadZipFile:
            return {
                "status": "INVALID",
                "errors": [f"Corrupted or invalid ZIP file: {zip_path}"],
                "manifest": None
            }
        except Exception as e:
            return {
                "status": "INVALID",
                "errors": [f"Unexpected error inspecting archive: {str(e)}"],
                "manifest": None
            }

        if errors:
            return {"status": "INVALID", "errors": errors, "manifest": manifest.to_dict()}

        return {
            "status": "VALID",
            "errors": [],
            "manifest": manifest.to_dict(),
            "entries_count": len(manifest.entries),
            "payload_files_count": len([e for e in manifest.entries if e.payload_path]),
            "mode": manifest.package_mode
        }
```

### `PackageVerifier.verify_package` — `Lines 40–126`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `40` إلى السطر `126` (`Lines 40–126`)
- **الوظيفة:** Verify the integrity, safety, and content authenticity of an update ZIP.
- **الكود الفعلي (`Lines 40–126`):**
```python
    def verify_package(zip_path: Path) -> Dict[str, Any]:
        """Verify the integrity, safety, and content authenticity of an update ZIP."""
        zip_path = zip_path.resolve()
        if not zip_path.exists():
            return {
                "status": "INVALID",
                "errors": [f"Archive file not found: {zip_path}"],
                "manifest": None
            }

        errors: List[str] = []
        try:
            with ZipFile(zip_path, "r") as zf:
                names = zf.namelist()

                # 1. Audit path traversal safety
                for name in names:
                    if not is_safe_archive_path(name):
                        errors.append(f"Unsafe path traversal detected in archive entry: {name}")

                if errors:
                    return {"status": "INVALID", "errors": errors, "manifest": None}

                # 2. Check manifest existence
                if "UPDATE_MANIFEST.json" not in names:
                    return {
                        "status": "INVALID",
                        "errors": ["Missing UPDATE_MANIFEST.json at root of archive"],
                        "manifest": None
                    }

                # 3. Read and parse manifest
                try:
                    manifest_bytes = zf.read("UPDATE_MANIFEST.json")
                    manifest_data = json.loads(manifest_bytes.decode("utf-8"))
                    manifest = UpdateManifest.from_dict(manifest_data)
                except Exception as e:
                    return {
                        "status": "INVALID",
                        "errors": [f"Malformed UPDATE_MANIFEST.json: {str(e)}"],
                        "manifest": None
                    }

                # 4. Verify each payload file's byte hash against manifest
                for entry in manifest.entries:
                    if not entry.payload_path:
                        continue
                    if entry.payload_path not in names:
                        errors.append(f"Payload file missing in archive: {entry.payload_path}")
                        continue

                    payload_bytes = zf.read(entry.payload_path)
                    payload_sha = compute_bytes_sha256(payload_bytes)

                    if payload_sha != entry.new_sha256:
                        errors.append(
                            f"Corrupted payload for {entry.path}: expected {entry.new_sha256}, got {payload_sha}"
                        )
                    if len(payload_bytes) != entry.size_bytes:
                        errors.append(
                            f"Byte size mismatch for {entry.path}: expected {entry.size_bytes}, got {len(payload_bytes)}"
                        )

        except BadZipFile:
            return {
                "status": "INVALID",
                "errors": [f"Corrupted or invalid ZIP file: {zip_path}"],
                "manifest": None
            }
        except Exception as e:
            return {
                "status": "INVALID",
                "errors": [f"Unexpected error inspecting archive: {str(e)}"],
                "manifest": None
            }

        if errors:
            return {"status": "INVALID", "errors": errors, "manifest": manifest.to_dict()}

        return {
            "status": "VALID",
            "errors": [],
            "manifest": manifest.to_dict(),
            "entries_count": len(manifest.entries),
            "payload_files_count": len([e for e in manifest.entries if e.payload_path]),
            "mode": manifest.package_mode
        }
```
