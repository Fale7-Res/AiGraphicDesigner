# مرآة الكود التفصيلية: `tools/update_packages/scanner.py`

> **تنبيه مرجعية الكود (`AUTO-GENERATED MIRROR — DO NOT HAND-EDIT CODE SNIPPETS`):**
> الملف البرمجي الأصلي `tools/update_packages/scanner.py` هو **المرجع التنفيذي الوحيد (`Sole Implementation Authority`)**. تم توليد هذه المرآة آلياً عبر `tools/memory_guard/sync_code_mirrors.py`؛ أي تعديل في الكود الأصلي يستلزم إعادة تشغيل أداة المزامنة فوراً لمنع تحول المرآة إلى نسخة قديمة (`Stale Copy`).

## 1. بطاقة تعريف الملف (`File Overview`)
- **المسار الفعلي (`Source File`):** `tools/update_packages/scanner.py`
- **الدور المعماري (`Architectural Role`):** First-Party Source Module
- **إجمالي عدد الأسطر (`Total Lines`):** `168` (`Lines 1–168`)
- **بصمة الملف (`SHA-256`):** `de9373d1d97b30de13beecb4cbef17d514b5b474c36e0379be007e964f39f0e7`
- **الوصف التفصيلي:** ملف برمجي ضمن معمارية AI Graphic Designer.

## 2. خريطة العلاقات وتدفق البيانات (`File Relationships — بياخد منين وبيرمي فين`)

| الاتجاه (`Direction`) | الملف أو المكوّن المرتبط (`Related Target / Source`) | البيانات أو الاستدعاء (`Payload / Call`) | تأثير التعديل (`Change Impact`) |
| :--- | :--- | :--- | :--- |
| **مستقل (`Standalone`)** | `None` | لا توجد ارتباطات خارجية مباشرة حالياً | مراجعة هذا الملف فقط عند التعديل. |

## 3. فهرس الدوال والكلاسات والرموز الداخلية (`Symbols, Methods & Nested Functions Table`)

| الاسم (`Symbol Name`) | النوع (`Kind`) | نطاق الأسطر (`Exact Lines`) | التوقيع (`Signature`) | الوظيفة التفصيلية (`Purpose`) |
| :--- | :--- | :--- | :--- | :--- |
| `calculate_stream_sha256` | `function` | `Lines 52–58` | `def calculate_stream_sha256(file_path: Path) -> str:` | Compute the SHA-256 hexadecimal digest of a file safely in 64 KiB chunks. |
| `compute_bytes_sha256` | `function` | `Lines 61–63` | `def compute_bytes_sha256(data: bytes) -> str:` | Compute SHA-256 digest of raw byte content. |
| `is_binary_file` | `function` | `Lines 66–77` | `def is_binary_file(file_path: Path) -> bool:` | Check if file is binary by extension or null-byte heuristic in the first 8 KiB. |
| `is_secret_file` | `function` | `Lines 80–86` | `def is_secret_file(file_path: Path) -> bool:` | Determine if a file name or path suggests it contains credentials/secrets. |
| `WorkspaceScanner` | `class` | `Lines 89–167` | `class WorkspaceScanner:` | Scans repository files and constructs deterministic inventory maps. |
| `WorkspaceScanner.__init__` | `method` | `Lines 92–102` | `def __init__(` | رمز برمجي موثق. |
| `WorkspaceScanner.should_exclude_path` | `method` | `Lines 104–138` | `def should_exclude_path(self, path: Path) -> Tuple[bool, str]:` | Check if a path should be excluded, returning (is_excluded, reason). |
| `WorkspaceScanner.scan` | `method` | `Lines 140–167` | `def scan(self) -> Dict[str, FileRecord]:` | Scan workspace and return a dictionary of normalized_posix_path -> FileRecord. |

## 4. التوثيق بالسطر والمقتطفات الفعلية للكود (`Exact Line Numbers & Verbatim Code Snippets`)

### `calculate_stream_sha256` — `Lines 52–58`
- **النوع:** `function`
- **نطاق الأسطر الدقيق:** من السطر `52` إلى السطر `58` (`Lines 52–58`)
- **الوظيفة:** Compute the SHA-256 hexadecimal digest of a file safely in 64 KiB chunks.
- **الكود الفعلي (`Lines 52–58`):**
```python
def calculate_stream_sha256(file_path: Path) -> str:
    """Compute the SHA-256 hexadecimal digest of a file safely in 64 KiB chunks."""
    h = hashlib.sha256()
    with file_path.open("rb") as f:
        while chunk := f.read(65536):
            h.update(chunk)
    return h.hexdigest()
```

### `compute_bytes_sha256` — `Lines 61–63`
- **النوع:** `function`
- **نطاق الأسطر الدقيق:** من السطر `61` إلى السطر `63` (`Lines 61–63`)
- **الوظيفة:** Compute SHA-256 digest of raw byte content.
- **الكود الفعلي (`Lines 61–63`):**
```python
def compute_bytes_sha256(data: bytes) -> str:
    """Compute SHA-256 digest of raw byte content."""
    return hashlib.sha256(data).hexdigest()
```

### `is_binary_file` — `Lines 66–77`
- **النوع:** `function`
- **نطاق الأسطر الدقيق:** من السطر `66` إلى السطر `77` (`Lines 66–77`)
- **الوظيفة:** Check if file is binary by extension or null-byte heuristic in the first 8 KiB.
- **الكود الفعلي (`Lines 66–77`):**
```python
def is_binary_file(file_path: Path) -> bool:
    """Check if file is binary by extension or null-byte heuristic in the first 8 KiB."""
    if file_path.suffix.lower() in BINARY_EXTENSIONS:
        return True
    try:
        with file_path.open("rb") as f:
            chunk = f.read(8192)
            if b"\x00" in chunk:
                return True
    except (OSError, PermissionError):
        return False
    return False
```

### `is_secret_file` — `Lines 80–86`
- **النوع:** `function`
- **نطاق الأسطر الدقيق:** من السطر `80` إلى السطر `86` (`Lines 80–86`)
- **الوظيفة:** Determine if a file name or path suggests it contains credentials/secrets.
- **الكود الفعلي (`Lines 80–86`):**
```python
def is_secret_file(file_path: Path) -> bool:
    """Determine if a file name or path suggests it contains credentials/secrets."""
    name = file_path.name
    for pattern in DEFAULT_EXCLUDED_FILE_PATTERNS[:5]:
        if pattern.match(name):
            return True
    return False
```

### `WorkspaceScanner` — `Lines 89–167`
- **النوع:** `class`
- **نطاق الأسطر الدقيق:** من السطر `89` إلى السطر `167` (`Lines 89–167`)
- **الوظيفة:** Scans repository files and constructs deterministic inventory maps.
- **الكود الفعلي (`Lines 89–167`):**
```python
class WorkspaceScanner:
    """Scans repository files and constructs deterministic inventory maps."""

    def __init__(
        self,
        root_dir: Path,
        excluded_dirs: Optional[Set[str]] = None,
        custom_excluded_subpaths: Optional[Set[str]] = None
    ):
        self.root_dir = root_dir.resolve()
        self.excluded_dirs = set(DEFAULT_EXCLUDED_DIR_NAMES)
        if excluded_dirs:
            self.excluded_dirs.update(excluded_dirs)
        self.custom_excluded_subpaths = custom_excluded_subpaths or set()

    def should_exclude_path(self, path: Path) -> Tuple[bool, str]:
        """Check if a path should be excluded, returning (is_excluded, reason)."""
        try:
            rel = path.relative_to(self.root_dir)
        except ValueError:
            return True, "Path outside workspace root"

        rel_parts = rel.parts
        # Check parent directories
        for part in rel_parts[:-1]:
            if part in self.excluded_dirs:
                return True, f"Excluded directory: {part}"

        # Check export and output directories to prevent recursion
        posix_rel = rel.as_posix()
        if posix_rel.startswith("exports/updates/") or posix_rel == "exports/updates":
            return True, "Update package output directory"
        if posix_rel.startswith("updates/packages/") or posix_rel.startswith("updates/baselines/"):
            return True, "Legacy update directory"
        if posix_rel.startswith("tools/update_packages/registry/") or posix_rel == "tools/update_packages/registry":
            return True, "Update tool internal state registry"

        for subpath in self.custom_excluded_subpaths:
            if posix_rel.startswith(subpath):
                return True, f"Custom excluded subpath: {subpath}"

        if path.is_file():
            name = path.name
            if is_secret_file(path):
                return True, f"Secret screening exclusion: {name}"
            for pat in DEFAULT_EXCLUDED_FILE_PATTERNS:
                if pat.match(name):
                    return True, f"Excluded file pattern: {pat.pattern}"

        return False, ""

    def scan(self) -> Dict[str, FileRecord]:
        """Scan workspace and return a dictionary of normalized_posix_path -> FileRecord."""
        records: Dict[str, FileRecord] = {}
        if not self.root_dir.exists():
            return records

        for p in sorted(self.root_dir.rglob("*")):
            if not p.is_file():
                continue
            is_excluded, _ = self.should_exclude_path(p)
            if is_excluded:
                continue

            rel_posix = p.relative_to(self.root_dir).as_posix()
            try:
                stat = p.stat()
                mtime_utc = datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat()
                records[rel_posix] = FileRecord(
                    path=rel_posix,
                    sha256=calculate_stream_sha256(p),
                    size_bytes=stat.st_size,
                    is_binary=is_binary_file(p),
                    last_modified_utc=mtime_utc
                )
            except (OSError, PermissionError):
                continue

        return records
```

### `WorkspaceScanner.__init__` — `Lines 92–102`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `92` إلى السطر `102` (`Lines 92–102`)
- **الوظيفة:** رمز برمجي موثق.
- **الكود الفعلي (`Lines 92–102`):**
```python
    def __init__(
        self,
        root_dir: Path,
        excluded_dirs: Optional[Set[str]] = None,
        custom_excluded_subpaths: Optional[Set[str]] = None
    ):
        self.root_dir = root_dir.resolve()
        self.excluded_dirs = set(DEFAULT_EXCLUDED_DIR_NAMES)
        if excluded_dirs:
            self.excluded_dirs.update(excluded_dirs)
        self.custom_excluded_subpaths = custom_excluded_subpaths or set()
```

### `WorkspaceScanner.should_exclude_path` — `Lines 104–138`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `104` إلى السطر `138` (`Lines 104–138`)
- **الوظيفة:** Check if a path should be excluded, returning (is_excluded, reason).
- **الكود الفعلي (`Lines 104–138`):**
```python
    def should_exclude_path(self, path: Path) -> Tuple[bool, str]:
        """Check if a path should be excluded, returning (is_excluded, reason)."""
        try:
            rel = path.relative_to(self.root_dir)
        except ValueError:
            return True, "Path outside workspace root"

        rel_parts = rel.parts
        # Check parent directories
        for part in rel_parts[:-1]:
            if part in self.excluded_dirs:
                return True, f"Excluded directory: {part}"

        # Check export and output directories to prevent recursion
        posix_rel = rel.as_posix()
        if posix_rel.startswith("exports/updates/") or posix_rel == "exports/updates":
            return True, "Update package output directory"
        if posix_rel.startswith("updates/packages/") or posix_rel.startswith("updates/baselines/"):
            return True, "Legacy update directory"
        if posix_rel.startswith("tools/update_packages/registry/") or posix_rel == "tools/update_packages/registry":
            return True, "Update tool internal state registry"

        for subpath in self.custom_excluded_subpaths:
            if posix_rel.startswith(subpath):
                return True, f"Custom excluded subpath: {subpath}"

        if path.is_file():
            name = path.name
            if is_secret_file(path):
                return True, f"Secret screening exclusion: {name}"
            for pat in DEFAULT_EXCLUDED_FILE_PATTERNS:
                if pat.match(name):
                    return True, f"Excluded file pattern: {pat.pattern}"

        return False, ""
```

### `WorkspaceScanner.scan` — `Lines 140–167`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `140` إلى السطر `167` (`Lines 140–167`)
- **الوظيفة:** Scan workspace and return a dictionary of normalized_posix_path -> FileRecord.
- **الكود الفعلي (`Lines 140–167`):**
```python
    def scan(self) -> Dict[str, FileRecord]:
        """Scan workspace and return a dictionary of normalized_posix_path -> FileRecord."""
        records: Dict[str, FileRecord] = {}
        if not self.root_dir.exists():
            return records

        for p in sorted(self.root_dir.rglob("*")):
            if not p.is_file():
                continue
            is_excluded, _ = self.should_exclude_path(p)
            if is_excluded:
                continue

            rel_posix = p.relative_to(self.root_dir).as_posix()
            try:
                stat = p.stat()
                mtime_utc = datetime.fromtimestamp(stat.st_mtime, tz=timezone.utc).isoformat()
                records[rel_posix] = FileRecord(
                    path=rel_posix,
                    sha256=calculate_stream_sha256(p),
                    size_bytes=stat.st_size,
                    is_binary=is_binary_file(p),
                    last_modified_utc=mtime_utc
                )
            except (OSError, PermissionError):
                continue

        return records
```
