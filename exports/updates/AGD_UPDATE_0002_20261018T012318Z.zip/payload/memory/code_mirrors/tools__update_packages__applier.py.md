# مرآة الكود التفصيلية: `tools/update_packages/applier.py`

> **تنبيه مرجعية الكود (`AUTO-GENERATED MIRROR — DO NOT HAND-EDIT CODE SNIPPETS`):**
> الملف البرمجي الأصلي `tools/update_packages/applier.py` هو **المرجع التنفيذي الوحيد (`Sole Implementation Authority`)**. تم توليد هذه المرآة آلياً عبر `tools/memory_guard/sync_code_mirrors.py`؛ أي تعديل في الكود الأصلي يستلزم إعادة تشغيل أداة المزامنة فوراً لمنع تحول المرآة إلى نسخة قديمة (`Stale Copy`).

## 1. بطاقة تعريف الملف (`File Overview`)
- **المسار الفعلي (`Source File`):** `tools/update_packages/applier.py`
- **الدور المعماري (`Architectural Role`):** First-Party Source Module
- **إجمالي عدد الأسطر (`Total Lines`):** `146` (`Lines 1–146`)
- **بصمة الملف (`SHA-256`):** `5e995d5d73f67817fb56896001f49d622f2a1bf72fe9c6c7b4de151bebeb4a88`
- **الوصف التفصيلي:** ملف برمجي ضمن معمارية AI Graphic Designer.

## 2. خريطة العلاقات وتدفق البيانات (`File Relationships — بياخد منين وبيرمي فين`)

| الاتجاه (`Direction`) | الملف أو المكوّن المرتبط (`Related Target / Source`) | البيانات أو الاستدعاء (`Payload / Call`) | تأثير التعديل (`Change Impact`) |
| :--- | :--- | :--- | :--- |
| **مستقل (`Standalone`)** | `None` | لا توجد ارتباطات خارجية مباشرة حالياً | مراجعة هذا الملف فقط عند التعديل. |

## 3. فهرس الدوال والكلاسات والرموز الداخلية (`Symbols, Methods & Nested Functions Table`)

| الاسم (`Symbol Name`) | النوع (`Kind`) | نطاق الأسطر (`Exact Lines`) | التوقيع (`Signature`) | الوظيفة التفصيلية (`Purpose`) |
| :--- | :--- | :--- | :--- | :--- |
| `PackageApplier` | `class` | `Lines 16–145` | `class PackageApplier:` | Applies verified update packages safely and transactionally to a target workspace. |
| `PackageApplier.__init__` | `method` | `Lines 19–21` | `def __init__(self, target_dir: Path, enforce_base_match: bool = True):` | رمز برمجي موثق. |
| `PackageApplier.apply` | `method` | `Lines 23–145` | `def apply(self, zip_path: Path, dry_run: bool = False) -> Dict[str, Any]:` | Apply an update ZIP package transactionally to the target directory. |

## 4. التوثيق بالسطر والمقتطفات الفعلية للكود (`Exact Line Numbers & Verbatim Code Snippets`)

### `PackageApplier` — `Lines 16–145`
- **النوع:** `class`
- **نطاق الأسطر الدقيق:** من السطر `16` إلى السطر `145` (`Lines 16–145`)
- **الوظيفة:** Applies verified update packages safely and transactionally to a target workspace.
- **الكود الفعلي (`Lines 16–145`):**
```python
class PackageApplier:
    """Applies verified update packages safely and transactionally to a target workspace."""

    def __init__(self, target_dir: Path, enforce_base_match: bool = True):
        self.target_dir = target_dir.resolve()
        self.enforce_base_match = enforce_base_match

    def apply(self, zip_path: Path, dry_run: bool = False) -> Dict[str, Any]:
        """Apply an update ZIP package transactionally to the target directory."""
        # 1. Verify archive format and hashes
        verification = PackageVerifier.verify_package(zip_path)
        if verification["status"] != "VALID":
            return {
                "status": "FAILED",
                "stage": "VERIFICATION",
                "errors": verification["errors"]
            }

        manifest = UpdateManifest.from_dict(verification["manifest"])

        # 2. Check prerequisites against target workspace
        scanner = WorkspaceScanner(self.target_dir)
        current_target_files = scanner.scan()

        prereq_errors: List[str] = []
        for entry in manifest.entries:
            target_path = self.target_dir / entry.path
            current_rec = current_target_files.get(entry.path)

            if entry.operation in (FileOperation.MODIFY.value, FileOperation.DELETE.value):
                if not current_rec:
                    prereq_errors.append(f"Expected file to modify/delete not found in target: {entry.path}")
                elif self.enforce_base_match and entry.previous_sha256:
                    if current_rec.sha256 != entry.previous_sha256:
                        prereq_errors.append(
                            f"Base hash collision for {entry.path}: expected {entry.previous_sha256[:12]}..., found {current_rec.sha256[:12]}..."
                        )

            elif entry.operation == FileOperation.RENAME.value:
                old_rec = current_target_files.get(entry.renamed_from) if entry.renamed_from else None
                if not old_rec:
                    prereq_errors.append(f"Source file for rename not found: {entry.renamed_from}")
                elif self.enforce_base_match and entry.previous_sha256 and old_rec.sha256 != entry.previous_sha256:
                    prereq_errors.append(
                        f"Base hash collision for rename source {entry.renamed_from}: expected {entry.previous_sha256[:12]}..."
                    )

            elif entry.operation == FileOperation.ADD.value:
                if current_rec:
                    if self.enforce_base_match and current_rec.sha256 != entry.new_sha256:
                        prereq_errors.append(f"Cannot ADD file; path already exists with differing content: {entry.path}")

        if prereq_errors:
            return {
                "status": "FAILED",
                "stage": "PREREQUISITE_CHECK",
                "errors": prereq_errors
            }

        if dry_run:
            return {
                "status": "DRY_RUN_PASSED",
                "stage": "PREREQUISITE_CHECK",
                "update_id": manifest.update_id,
                "operations_count": len(manifest.entries),
                "target_dir": str(self.target_dir)
            }

        # 3. Stage payload extraction into temporary directory
        with tempfile.TemporaryDirectory(prefix="agd_stage_") as stage_dir_str:
            stage_dir = Path(stage_dir_str)
            try:
                with ZipFile(zip_path, "r") as zf:
                    for entry in manifest.entries:
                        if entry.payload_path:
                            dest = stage_dir / entry.path
                            dest.parent.mkdir(parents=True, exist_ok=True)
                            payload_bytes = zf.read(entry.payload_path)
                            dest.write_bytes(payload_bytes)
            except Exception as e:
                return {
                    "status": "FAILED",
                    "stage": "STAGING_EXTRACTION",
                    "errors": [f"Failed to extract payload to staging: {str(e)}"]
                }

            # 4. Transactionally apply modifications to target workspace
            applied_entries: List[str] = []
            try:
                for entry in manifest.entries:
                    target_file = self.target_dir / entry.path

                    if entry.operation in (FileOperation.ADD.value, FileOperation.MODIFY.value):
                        staged_file = stage_dir / entry.path
                        target_file.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(staged_file, target_file)
                        applied_entries.append(f"{entry.operation}: {entry.path}")

                    elif entry.operation == FileOperation.RENAME.value:
                        if entry.renamed_from:
                            old_file = self.target_dir / entry.renamed_from
                            if old_file.exists():
                                old_file.unlink()
                        staged_file = stage_dir / entry.path
                        target_file.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(staged_file, target_file)
                        applied_entries.append(f"RENAME: {entry.renamed_from} -> {entry.path}")

                    elif entry.operation == FileOperation.DELETE.value:
                        if target_file.exists():
                            target_file.unlink()
                            applied_entries.append(f"DELETE: {entry.path}")

            except Exception as e:
                return {
                    "status": "FAILED",
                    "stage": "APPLICATION_EXECUTION",
                    "errors": [f"Fatal error while applying files: {str(e)}"],
                    "applied_before_failure": applied_entries
                }

        return {
            "status": "APPLIED",
            "update_id": manifest.update_id,
            "mode": manifest.package_mode,
            "applied_count": len(applied_entries),
            "applied_entries": applied_entries,
            "target_dir": str(self.target_dir),
            "errors": []
        }
```

### `PackageApplier.__init__` — `Lines 19–21`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `19` إلى السطر `21` (`Lines 19–21`)
- **الوظيفة:** رمز برمجي موثق.
- **الكود الفعلي (`Lines 19–21`):**
```python
    def __init__(self, target_dir: Path, enforce_base_match: bool = True):
        self.target_dir = target_dir.resolve()
        self.enforce_base_match = enforce_base_match
```

### `PackageApplier.apply` — `Lines 23–145`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `23` إلى السطر `145` (`Lines 23–145`)
- **الوظيفة:** Apply an update ZIP package transactionally to the target directory.
- **الكود الفعلي (`Lines 23–145`):**
```python
    def apply(self, zip_path: Path, dry_run: bool = False) -> Dict[str, Any]:
        """Apply an update ZIP package transactionally to the target directory."""
        # 1. Verify archive format and hashes
        verification = PackageVerifier.verify_package(zip_path)
        if verification["status"] != "VALID":
            return {
                "status": "FAILED",
                "stage": "VERIFICATION",
                "errors": verification["errors"]
            }

        manifest = UpdateManifest.from_dict(verification["manifest"])

        # 2. Check prerequisites against target workspace
        scanner = WorkspaceScanner(self.target_dir)
        current_target_files = scanner.scan()

        prereq_errors: List[str] = []
        for entry in manifest.entries:
            target_path = self.target_dir / entry.path
            current_rec = current_target_files.get(entry.path)

            if entry.operation in (FileOperation.MODIFY.value, FileOperation.DELETE.value):
                if not current_rec:
                    prereq_errors.append(f"Expected file to modify/delete not found in target: {entry.path}")
                elif self.enforce_base_match and entry.previous_sha256:
                    if current_rec.sha256 != entry.previous_sha256:
                        prereq_errors.append(
                            f"Base hash collision for {entry.path}: expected {entry.previous_sha256[:12]}..., found {current_rec.sha256[:12]}..."
                        )

            elif entry.operation == FileOperation.RENAME.value:
                old_rec = current_target_files.get(entry.renamed_from) if entry.renamed_from else None
                if not old_rec:
                    prereq_errors.append(f"Source file for rename not found: {entry.renamed_from}")
                elif self.enforce_base_match and entry.previous_sha256 and old_rec.sha256 != entry.previous_sha256:
                    prereq_errors.append(
                        f"Base hash collision for rename source {entry.renamed_from}: expected {entry.previous_sha256[:12]}..."
                    )

            elif entry.operation == FileOperation.ADD.value:
                if current_rec:
                    if self.enforce_base_match and current_rec.sha256 != entry.new_sha256:
                        prereq_errors.append(f"Cannot ADD file; path already exists with differing content: {entry.path}")

        if prereq_errors:
            return {
                "status": "FAILED",
                "stage": "PREREQUISITE_CHECK",
                "errors": prereq_errors
            }

        if dry_run:
            return {
                "status": "DRY_RUN_PASSED",
                "stage": "PREREQUISITE_CHECK",
                "update_id": manifest.update_id,
                "operations_count": len(manifest.entries),
                "target_dir": str(self.target_dir)
            }

        # 3. Stage payload extraction into temporary directory
        with tempfile.TemporaryDirectory(prefix="agd_stage_") as stage_dir_str:
            stage_dir = Path(stage_dir_str)
            try:
                with ZipFile(zip_path, "r") as zf:
                    for entry in manifest.entries:
                        if entry.payload_path:
                            dest = stage_dir / entry.path
                            dest.parent.mkdir(parents=True, exist_ok=True)
                            payload_bytes = zf.read(entry.payload_path)
                            dest.write_bytes(payload_bytes)
            except Exception as e:
                return {
                    "status": "FAILED",
                    "stage": "STAGING_EXTRACTION",
                    "errors": [f"Failed to extract payload to staging: {str(e)}"]
                }

            # 4. Transactionally apply modifications to target workspace
            applied_entries: List[str] = []
            try:
                for entry in manifest.entries:
                    target_file = self.target_dir / entry.path

                    if entry.operation in (FileOperation.ADD.value, FileOperation.MODIFY.value):
                        staged_file = stage_dir / entry.path
                        target_file.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(staged_file, target_file)
                        applied_entries.append(f"{entry.operation}: {entry.path}")

                    elif entry.operation == FileOperation.RENAME.value:
                        if entry.renamed_from:
                            old_file = self.target_dir / entry.renamed_from
                            if old_file.exists():
                                old_file.unlink()
                        staged_file = stage_dir / entry.path
                        target_file.parent.mkdir(parents=True, exist_ok=True)
                        shutil.copy2(staged_file, target_file)
                        applied_entries.append(f"RENAME: {entry.renamed_from} -> {entry.path}")

                    elif entry.operation == FileOperation.DELETE.value:
                        if target_file.exists():
                            target_file.unlink()
                            applied_entries.append(f"DELETE: {entry.path}")

            except Exception as e:
                return {
                    "status": "FAILED",
                    "stage": "APPLICATION_EXECUTION",
                    "errors": [f"Fatal error while applying files: {str(e)}"],
                    "applied_before_failure": applied_entries
                }

        return {
            "status": "APPLIED",
            "update_id": manifest.update_id,
            "mode": manifest.package_mode,
            "applied_count": len(applied_entries),
            "applied_entries": applied_entries,
            "target_dir": str(self.target_dir),
            "errors": []
        }
```
