# مرآة الكود التفصيلية: `tools/update_packages/state_manager.py`

> **تنبيه مرجعية الكود (`AUTO-GENERATED MIRROR — DO NOT HAND-EDIT CODE SNIPPETS`):**
> الملف البرمجي الأصلي `tools/update_packages/state_manager.py` هو **المرجع التنفيذي الوحيد (`Sole Implementation Authority`)**. تم توليد هذه المرآة آلياً عبر `tools/memory_guard/sync_code_mirrors.py`؛ أي تعديل في الكود الأصلي يستلزم إعادة تشغيل أداة المزامنة فوراً لمنع تحول المرآة إلى نسخة قديمة (`Stale Copy`).

## 1. بطاقة تعريف الملف (`File Overview`)
- **المسار الفعلي (`Source File`):** `tools/update_packages/state_manager.py`
- **الدور المعماري (`Architectural Role`):** First-Party Source Module
- **إجمالي عدد الأسطر (`Total Lines`):** `168` (`Lines 1–168`)
- **بصمة الملف (`SHA-256`):** `9a6417e45751664c0b14442b419106d1a128ee174994edc183925cd3660523d7`
- **الوصف التفصيلي:** ملف برمجي ضمن معمارية AI Graphic Designer.

## 2. خريطة العلاقات وتدفق البيانات (`File Relationships — بياخد منين وبيرمي فين`)

| الاتجاه (`Direction`) | الملف أو المكوّن المرتبط (`Related Target / Source`) | البيانات أو الاستدعاء (`Payload / Call`) | تأثير التعديل (`Change Impact`) |
| :--- | :--- | :--- | :--- |
| **مستقل (`Standalone`)** | `None` | لا توجد ارتباطات خارجية مباشرة حالياً | مراجعة هذا الملف فقط عند التعديل. |

## 3. فهرس الدوال والكلاسات والرموز الداخلية (`Symbols, Methods & Nested Functions Table`)

| الاسم (`Symbol Name`) | النوع (`Kind`) | نطاق الأسطر (`Exact Lines`) | التوقيع (`Signature`) | الوظيفة التفصيلية (`Purpose`) |
| :--- | :--- | :--- | :--- | :--- |
| `UpdateStateManager` | `class` | `Lines 15–167` | `class UpdateStateManager:` | Manages baseline snapshots, acknowledged states, and export history. |
| `UpdateStateManager.__init__` | `method` | `Lines 18–25` | `def __init__(self, workspace_root: Path, registry_dir: Optional[Path] = None):` | رمز برمجي موثق. |
| `UpdateStateManager._ensure_state_file` | `method` | `Lines 27–36` | `def _ensure_state_file(self) -> None:` | رمز برمجي موثق. |
| `UpdateStateManager._read_state` | `method` | `Lines 38–48` | `def _read_state(self) -> Dict[str, Any]:` | رمز برمجي موثق. |
| `UpdateStateManager._write_state` | `method` | `Lines 50–51` | `def _write_state(self, state: Dict[str, Any]) -> None:` | رمز برمجي موثق. |
| `UpdateStateManager.get_git_commit` | `method` | `Lines 53–68` | `def get_git_commit(self) -> Optional[str]:` | Detect current Git HEAD commit if git repository is active and trustworthy. |
| `UpdateStateManager.initialize_baseline` | `method` | `Lines 70–102` | `def initialize_baseline(self, baseline_id: Optional[str] = None) -> BaselineInventory:` | Scan workspace and persist a new baseline inventory. |
| `UpdateStateManager.get_baseline` | `method` | `Lines 104–113` | `def get_baseline(self, baseline_id: str) -> Optional[BaselineInventory]:` | Load an existing baseline inventory by ID. |
| `UpdateStateManager.get_active_baseline` | `method` | `Lines 115–121` | `def get_active_baseline(self) -> Optional[BaselineInventory]:` | Retrieve the currently designated active baseline. |
| `UpdateStateManager.acknowledge_baseline` | `method` | `Lines 123–146` | `def acknowledge_baseline(self, baseline_id: str, acknowledged_by: str = "Owner", note: str = "Acknowledged") -> Dict[str, Any]:` | Explicitly record user or owner acknowledgment of a baseline. |
| `UpdateStateManager.record_export` | `method` | `Lines 148–152` | `def record_export(self, export_record: Dict[str, Any]) -> None:` | Record an exported package into the state history without advancing baseline automatically. |
| `UpdateStateManager.record_application` | `method` | `Lines 154–158` | `def record_application(self, application_record: Dict[str, Any]) -> None:` | Record an applied package into the state history. |
| `UpdateStateManager.get_next_sequence_number` | `method` | `Lines 160–163` | `def get_next_sequence_number(self) -> int:` | Calculate next package sequence number. |
| `UpdateStateManager.list_history` | `method` | `Lines 165–167` | `def list_history(self) -> Dict[str, Any]:` | Return complete state and export history. |

## 4. التوثيق بالسطر والمقتطفات الفعلية للكود (`Exact Line Numbers & Verbatim Code Snippets`)

### `UpdateStateManager` — `Lines 15–167`
- **النوع:** `class`
- **نطاق الأسطر الدقيق:** من السطر `15` إلى السطر `167` (`Lines 15–167`)
- **الوظيفة:** Manages baseline snapshots, acknowledged states, and export history.
- **الكود الفعلي (`Lines 15–167`):**
```python
class UpdateStateManager:
    """Manages baseline snapshots, acknowledged states, and export history."""

    def __init__(self, workspace_root: Path, registry_dir: Optional[Path] = None):
        self.workspace_root = workspace_root.resolve()
        self.registry_dir = (registry_dir or (self.workspace_root / "tools" / "update_packages" / "registry")).resolve()
        self.baselines_dir = self.registry_dir / "baselines"
        self.state_file = self.registry_dir / "update_state.json"

        self.baselines_dir.mkdir(parents=True, exist_ok=True)
        self._ensure_state_file()

    def _ensure_state_file(self) -> None:
        if not self.state_file.exists():
            initial_state = {
                "active_baseline_id": None,
                "acknowledged_baseline_id": None,
                "acknowledgment_history": [],
                "export_history": [],
                "application_history": []
            }
            self.state_file.write_text(json.dumps(initial_state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    def _read_state(self) -> Dict[str, Any]:
        try:
            return json.loads(self.state_file.read_text(encoding="utf-8"))
        except Exception:
            return {
                "active_baseline_id": None,
                "acknowledged_baseline_id": None,
                "acknowledgment_history": [],
                "export_history": [],
                "application_history": []
            }

    def _write_state(self, state: Dict[str, Any]) -> None:
        self.state_file.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    def get_git_commit(self) -> Optional[str]:
        """Detect current Git HEAD commit if git repository is active and trustworthy."""
        try:
            res = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=str(self.workspace_root),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                check=False
            )
            if res.returncode == 0 and res.stdout.strip():
                return res.stdout.strip()
        except Exception:
            pass
        return None

    def initialize_baseline(self, baseline_id: Optional[str] = None) -> BaselineInventory:
        """Scan workspace and persist a new baseline inventory."""
        now_utc = datetime.now(timezone.utc)
        if not baseline_id:
            ts = now_utc.strftime("%Y%m%dT%H%M%SZ")
            baseline_id = f"BASE_{ts}"

        scanner = WorkspaceScanner(self.workspace_root)
        files = scanner.scan()
        git_commit = self.get_git_commit()

        inventory = BaselineInventory(
            baseline_id=baseline_id,
            repo_identity="AI Graphic Designer",
            created_at_utc=now_utc.isoformat(),
            tool_version="1.0.0",
            schema_version="1.0.0",
            git_commit=git_commit,
            inclusion_policy="tracked_first_party",
            exclusion_policy="standard_anti_leak",
            files=files
        )

        baseline_file = self.baselines_dir / f"{baseline_id}.json"
        baseline_file.write_text(inventory.to_json(), encoding="utf-8")

        state = self._read_state()
        state["active_baseline_id"] = baseline_id
        if not state.get("acknowledged_baseline_id"):
            state["acknowledged_baseline_id"] = baseline_id
        self._write_state(state)

        return inventory

    def get_baseline(self, baseline_id: str) -> Optional[BaselineInventory]:
        """Load an existing baseline inventory by ID."""
        baseline_file = self.baselines_dir / f"{baseline_id}.json"
        if not baseline_file.exists():
            return None
        try:
            data = json.loads(baseline_file.read_text(encoding="utf-8"))
            return BaselineInventory.from_dict(data)
        except Exception:
            return None

    def get_active_baseline(self) -> Optional[BaselineInventory]:
        """Retrieve the currently designated active baseline."""
        state = self._read_state()
        base_id = state.get("active_baseline_id") or state.get("acknowledged_baseline_id")
        if not base_id:
            return None
        return self.get_baseline(base_id)

    def acknowledge_baseline(self, baseline_id: str, acknowledged_by: str = "Owner", note: str = "Acknowledged") -> Dict[str, Any]:
        """Explicitly record user or owner acknowledgment of a baseline."""
        inventory = self.get_baseline(baseline_id)
        if not inventory:
            raise FileNotFoundError(f"Baseline not found: {baseline_id}")

        now_utc = datetime.now(timezone.utc).isoformat()
        state = self._read_state()
        state["acknowledged_baseline_id"] = baseline_id
        state["active_baseline_id"] = baseline_id
        state.setdefault("acknowledgment_history", []).append({
            "baseline_id": baseline_id,
            "acknowledged_by": acknowledged_by,
            "note": note,
            "acknowledged_at_utc": now_utc
        })
        self._write_state(state)

        return {
            "status": "ACKNOWLEDGED",
            "baseline_id": baseline_id,
            "acknowledged_by": acknowledged_by,
            "acknowledged_at_utc": now_utc
        }

    def record_export(self, export_record: Dict[str, Any]) -> None:
        """Record an exported package into the state history without advancing baseline automatically."""
        state = self._read_state()
        state.setdefault("export_history", []).append(export_record)
        self._write_state(state)

    def record_application(self, application_record: Dict[str, Any]) -> None:
        """Record an applied package into the state history."""
        state = self._read_state()
        state.setdefault("application_history", []).append(application_record)
        self._write_state(state)

    def get_next_sequence_number(self) -> int:
        """Calculate next package sequence number."""
        state = self._read_state()
        return len(state.get("export_history", [])) + 1

    def list_history(self) -> Dict[str, Any]:
        """Return complete state and export history."""
        return self._read_state()
```

### `UpdateStateManager.__init__` — `Lines 18–25`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `18` إلى السطر `25` (`Lines 18–25`)
- **الوظيفة:** رمز برمجي موثق.
- **الكود الفعلي (`Lines 18–25`):**
```python
    def __init__(self, workspace_root: Path, registry_dir: Optional[Path] = None):
        self.workspace_root = workspace_root.resolve()
        self.registry_dir = (registry_dir or (self.workspace_root / "tools" / "update_packages" / "registry")).resolve()
        self.baselines_dir = self.registry_dir / "baselines"
        self.state_file = self.registry_dir / "update_state.json"

        self.baselines_dir.mkdir(parents=True, exist_ok=True)
        self._ensure_state_file()
```

### `UpdateStateManager._ensure_state_file` — `Lines 27–36`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `27` إلى السطر `36` (`Lines 27–36`)
- **الوظيفة:** رمز برمجي موثق.
- **الكود الفعلي (`Lines 27–36`):**
```python
    def _ensure_state_file(self) -> None:
        if not self.state_file.exists():
            initial_state = {
                "active_baseline_id": None,
                "acknowledged_baseline_id": None,
                "acknowledgment_history": [],
                "export_history": [],
                "application_history": []
            }
            self.state_file.write_text(json.dumps(initial_state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
```

### `UpdateStateManager._read_state` — `Lines 38–48`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `38` إلى السطر `48` (`Lines 38–48`)
- **الوظيفة:** رمز برمجي موثق.
- **الكود الفعلي (`Lines 38–48`):**
```python
    def _read_state(self) -> Dict[str, Any]:
        try:
            return json.loads(self.state_file.read_text(encoding="utf-8"))
        except Exception:
            return {
                "active_baseline_id": None,
                "acknowledged_baseline_id": None,
                "acknowledgment_history": [],
                "export_history": [],
                "application_history": []
            }
```

### `UpdateStateManager._write_state` — `Lines 50–51`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `50` إلى السطر `51` (`Lines 50–51`)
- **الوظيفة:** رمز برمجي موثق.
- **الكود الفعلي (`Lines 50–51`):**
```python
    def _write_state(self, state: Dict[str, Any]) -> None:
        self.state_file.write_text(json.dumps(state, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
```

### `UpdateStateManager.get_git_commit` — `Lines 53–68`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `53` إلى السطر `68` (`Lines 53–68`)
- **الوظيفة:** Detect current Git HEAD commit if git repository is active and trustworthy.
- **الكود الفعلي (`Lines 53–68`):**
```python
    def get_git_commit(self) -> Optional[str]:
        """Detect current Git HEAD commit if git repository is active and trustworthy."""
        try:
            res = subprocess.run(
                ["git", "rev-parse", "HEAD"],
                cwd=str(self.workspace_root),
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                check=False
            )
            if res.returncode == 0 and res.stdout.strip():
                return res.stdout.strip()
        except Exception:
            pass
        return None
```

### `UpdateStateManager.initialize_baseline` — `Lines 70–102`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `70` إلى السطر `102` (`Lines 70–102`)
- **الوظيفة:** Scan workspace and persist a new baseline inventory.
- **الكود الفعلي (`Lines 70–102`):**
```python
    def initialize_baseline(self, baseline_id: Optional[str] = None) -> BaselineInventory:
        """Scan workspace and persist a new baseline inventory."""
        now_utc = datetime.now(timezone.utc)
        if not baseline_id:
            ts = now_utc.strftime("%Y%m%dT%H%M%SZ")
            baseline_id = f"BASE_{ts}"

        scanner = WorkspaceScanner(self.workspace_root)
        files = scanner.scan()
        git_commit = self.get_git_commit()

        inventory = BaselineInventory(
            baseline_id=baseline_id,
            repo_identity="AI Graphic Designer",
            created_at_utc=now_utc.isoformat(),
            tool_version="1.0.0",
            schema_version="1.0.0",
            git_commit=git_commit,
            inclusion_policy="tracked_first_party",
            exclusion_policy="standard_anti_leak",
            files=files
        )

        baseline_file = self.baselines_dir / f"{baseline_id}.json"
        baseline_file.write_text(inventory.to_json(), encoding="utf-8")

        state = self._read_state()
        state["active_baseline_id"] = baseline_id
        if not state.get("acknowledged_baseline_id"):
            state["acknowledged_baseline_id"] = baseline_id
        self._write_state(state)

        return inventory
```

### `UpdateStateManager.get_baseline` — `Lines 104–113`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `104` إلى السطر `113` (`Lines 104–113`)
- **الوظيفة:** Load an existing baseline inventory by ID.
- **الكود الفعلي (`Lines 104–113`):**
```python
    def get_baseline(self, baseline_id: str) -> Optional[BaselineInventory]:
        """Load an existing baseline inventory by ID."""
        baseline_file = self.baselines_dir / f"{baseline_id}.json"
        if not baseline_file.exists():
            return None
        try:
            data = json.loads(baseline_file.read_text(encoding="utf-8"))
            return BaselineInventory.from_dict(data)
        except Exception:
            return None
```

### `UpdateStateManager.get_active_baseline` — `Lines 115–121`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `115` إلى السطر `121` (`Lines 115–121`)
- **الوظيفة:** Retrieve the currently designated active baseline.
- **الكود الفعلي (`Lines 115–121`):**
```python
    def get_active_baseline(self) -> Optional[BaselineInventory]:
        """Retrieve the currently designated active baseline."""
        state = self._read_state()
        base_id = state.get("active_baseline_id") or state.get("acknowledged_baseline_id")
        if not base_id:
            return None
        return self.get_baseline(base_id)
```

### `UpdateStateManager.acknowledge_baseline` — `Lines 123–146`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `123` إلى السطر `146` (`Lines 123–146`)
- **الوظيفة:** Explicitly record user or owner acknowledgment of a baseline.
- **الكود الفعلي (`Lines 123–146`):**
```python
    def acknowledge_baseline(self, baseline_id: str, acknowledged_by: str = "Owner", note: str = "Acknowledged") -> Dict[str, Any]:
        """Explicitly record user or owner acknowledgment of a baseline."""
        inventory = self.get_baseline(baseline_id)
        if not inventory:
            raise FileNotFoundError(f"Baseline not found: {baseline_id}")

        now_utc = datetime.now(timezone.utc).isoformat()
        state = self._read_state()
        state["acknowledged_baseline_id"] = baseline_id
        state["active_baseline_id"] = baseline_id
        state.setdefault("acknowledgment_history", []).append({
            "baseline_id": baseline_id,
            "acknowledged_by": acknowledged_by,
            "note": note,
            "acknowledged_at_utc": now_utc
        })
        self._write_state(state)

        return {
            "status": "ACKNOWLEDGED",
            "baseline_id": baseline_id,
            "acknowledged_by": acknowledged_by,
            "acknowledged_at_utc": now_utc
        }
```

### `UpdateStateManager.record_export` — `Lines 148–152`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `148` إلى السطر `152` (`Lines 148–152`)
- **الوظيفة:** Record an exported package into the state history without advancing baseline automatically.
- **الكود الفعلي (`Lines 148–152`):**
```python
    def record_export(self, export_record: Dict[str, Any]) -> None:
        """Record an exported package into the state history without advancing baseline automatically."""
        state = self._read_state()
        state.setdefault("export_history", []).append(export_record)
        self._write_state(state)
```

### `UpdateStateManager.record_application` — `Lines 154–158`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `154` إلى السطر `158` (`Lines 154–158`)
- **الوظيفة:** Record an applied package into the state history.
- **الكود الفعلي (`Lines 154–158`):**
```python
    def record_application(self, application_record: Dict[str, Any]) -> None:
        """Record an applied package into the state history."""
        state = self._read_state()
        state.setdefault("application_history", []).append(application_record)
        self._write_state(state)
```

### `UpdateStateManager.get_next_sequence_number` — `Lines 160–163`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `160` إلى السطر `163` (`Lines 160–163`)
- **الوظيفة:** Calculate next package sequence number.
- **الكود الفعلي (`Lines 160–163`):**
```python
    def get_next_sequence_number(self) -> int:
        """Calculate next package sequence number."""
        state = self._read_state()
        return len(state.get("export_history", [])) + 1
```

### `UpdateStateManager.list_history` — `Lines 165–167`
- **النوع:** `method`
- **نطاق الأسطر الدقيق:** من السطر `165` إلى السطر `167` (`Lines 165–167`)
- **الوظيفة:** Return complete state and export history.
- **الكود الفعلي (`Lines 165–167`):**
```python
    def list_history(self) -> Dict[str, Any]:
        """Return complete state and export history."""
        return self._read_state()
```
