def old_function(): return 'rename me'
