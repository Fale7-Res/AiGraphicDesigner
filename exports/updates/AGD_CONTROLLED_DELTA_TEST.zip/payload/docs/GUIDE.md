# User Guide v2.0
Updated instructions for clean SVG.
