# Architecture v2.0
Updated specification with vector engine.
