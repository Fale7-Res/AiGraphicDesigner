# New Feature Specification
Clean SVG Pen Tool details.
