# سجل تغييرات الملفات للحزمة: `UPDATE_CONTROLLED_ACCEPTANCE`

| العملية (`Operation`) | مسار الملف (`Path`) | الحجم (`Bytes`) | نوع الملف (`Type`) | SHA-256 السابق | SHA-256 الجديد |
| :---: | :--- | :---: | :---: | :---: | :---: |
| `ADD` | `docs/NEW_FEATURE_SPEC.md` | 58 | Text | `-` | `45894b6a738f...` |
| `DELETE` | `docs/DEPRECATED.md` | 0 | Text | `fc5ae7c7941b...` | `-` |
| `MODIFY` | `assets/logo.png` | 40 | Binary | `cc902a62053e...` | `c40184891ef3...` |
| `MODIFY` | `docs/ARCHITECTURE.md` | 64 | Text | `586445e6cd69...` | `091df92da617...` |
| `MODIFY` | `docs/GUIDE.md` | 56 | Text | `668f1e08b7ae...` | `16f35a7025a0...` |
| `MODIFY` | `src/core/math_utils.py` | 63 | Text | `57df89fa4642...` | `ffd3570a2443...` |
| `MODIFY` | `src/pipeline.py` | 45 | Text | `c36f8a1844ef...` | `fdc014035087...` |
| `RENAME` | `src/renamed_feature.py` | 40 | Text | `b57a77388f8e...` | `b57a77388f8e...` |
